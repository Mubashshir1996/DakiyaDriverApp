import React , { PureComponent } from 'react';
import {Route} from './src/navigation/Route';

export default class App extends PureComponent{


  
  render(){
    
    return(
      <Route></Route>
    )
  }

  
}