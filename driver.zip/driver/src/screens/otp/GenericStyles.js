import {StyleSheet} from 'react-native';

import colors from '../../utility/color';

export const GenericStyles = StyleSheet.create({
  row: { 
    flexDirection: 'row',
    alignItems: 'center'
  },
  column: {
    flexDirection: 'column'
  },
  mr12: {
    marginRight: 12
  },
  mt12: {
    marginTop: 12,
  },
  mt24: {
    marginTop: 24,
    left:8  
  },
  mr4: {
    marginRight: 4,
  },
  mb12: {
    marginBottom: 12,
  },
  upperCase: {
    textTransform: 'uppercase',
  },
  noBorder: {
    borderWidth: 0,
  },
  whiteBackgroundContainer: {
    backgroundColor: colors.WHITE,
    flex: 1,
  },
  bold: {
    fontWeight:'bold',
  },
  fill: {
    flex: 1,
  },
  capitalize: {
    textTransform: 'capitalize',
  },
  positiveText: {
    color: colors.GREEN,
  },
  negativeText: {
    color: colors.RED,
  },
  centerAlignedText: {
    textAlign: "center",
    color:colors.FONT_COLOR
  },
  centerAligned: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  highlightedInfoText: {
    fontSize: 12,
    backgroundColor: colors.LIGHT_RED,
    padding: 8,
    borderRadius: 2,
  },
  card: {
    borderColor: colors.FONT_COLOR,
    borderTopWidth: 1,
    borderRightWidth: 1,
    borderBottomWidth: 2,
    borderLeftWidth: 1,
    borderRadius: 5,
    padding: 12,
    backgroundColor: colors.WHITE,
  },
  underline: {
    textDecorationLine: 'underline',
  },
  greyBar: {
    height: 1,
    backgroundColor: colors.FONT_COLOR,
  },
  p16: {
    padding: 16,
  },
  navigationHeaderBorder: {
    borderBottomWidth: 1,
    borderBottomColor: colors.FONT_COLOR,
  },
  rightAligned: {
    justifyContent: 'flex-end',
  },

});

export function elevationShadowStyle(elevation) {
  return {
    elevation,
    shadowColor: 'black',
    shadowOffset: {width: 0, height: 0.5 * elevation},
    shadowOpacity: 0.5,
    shadowRadius: 0.8 * elevation,
    borderWidth: 0.1,
  };
}