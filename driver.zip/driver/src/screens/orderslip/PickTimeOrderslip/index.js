import React, { Component } from 'react';
import { Text, View,Image, StyleSheet, LayoutAnimation, Platform, UIManager, TouchableOpacity,ScrollView, StatusBar, TextInput } from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import CustomText from '../../../components/CustomText';
import { CustomTextInputInfo } from '../../../components/customview';
import colors from '../../../utility/color';
import { Footer } from '../../commonview/footer';







export default class PickTimeOrderSlip extends Component {
  constructor() {
    super();

    this.state = { expanded: false,isDropDown:false,isCity:false ,isState:false,isCountry:false,isPinCode:false}

    if (Platform.OS === 'android') {
      UIManager.setLayoutAnimationEnabledExperimental(true);
    }
  }

  changeLayout = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({ expanded: !this.state.expanded });
  }
  changeLayoutDropisCity = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    // this.setState({ isDropDown: !this.state.isDropDown });
    this.setState({ isCity: !this.state.isCity });

  }
  changeLayoutDropisState = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({ isState: !this.state.isState });

  }
  changeLayoutDropisCountry = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({ isCountry: !this.state.isCountry });

  }
  changeLayoutDropisPinCode= () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({ isPinCode: !this.state.isPinCode });

  }
 

  render() {
    const options = [
      {
        label: 'News'
      },
      {
        label: 'Design'
      },
      {
        label: 'Sales'
      },
      {
        label: 'Marketing'
      },
      {
        label: 'Customer Success'
      }
    ];
    const {navigation } = this.props;

    return (
      <View style={styles.container}>
        <View 
          style={{
            aspectRatio:5.1,
            flex:1,
            height:wp('18%'),
            borderWidth:1.2,
            borderColor:colors.WHITE_GREY,
            alignSelf:'center',
            flexDirection:'row',
            justifyContent:'space-between',
            marginTop:30
          }}
        >
          <Image 
            source={require('../../../../assets/images/ic_pic_time.png')} 
            resizeMode='contain' 
            style={{flexDirection:'row',marginLeft:10,width:40,height:30,alignSelf:'center'}}
          ></Image>
          <Text style={{flexDirection:'row',fontSize:hp('2.3%'),fontFamily:'NunitoSans-Bold',alignSelf:'center'}}>Pickup Time</Text>
          <TouchableOpacity  onPress={this.changeLayout} style={{alignSelf:'center'}}>
            {this.state.expanded == false?      
              <Image 
                source={require('../../../../assets/images/ic_downn.png')} 
                resizeMode='contain' 
                style={{flexDirection:'row',width:40,height:40,right:10,alignSelf:'center'}}
              ></Image>
              :
              <Image 
                source={require('../../../../assets/images/ic_up.png')} 
                resizeMode='contain' 
                style={{width:40,height:40,right:10,alignSelf:'center'}}
              ></Image>
            } 
          </TouchableOpacity>
        </View>  
        <View style={{ height: this.state.expanded ? null : 0, overflow: 'hidden' }}>
          <View style={{flexDirection:'column',marginLeft:10,marginTop:hp('3%')}}>
            <CustomText style={{fontSize:hp('2%'),fontFamily:'NunitoSans-Regular'}}>
              Pickup Slot
            </CustomText>
            <CustomText style={{fontSize:hp('2%'),fontFamily:'NunitoSans-Regular',marginTop:hp('2.2%'),color:colors.FONT_COLOR}}>
              Speed post
            </CustomText>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={{lex:1,flexDirection:'row',marginTop:hp('3%'),marginLeft:wp('3%')}}>
              <Footer 
                navigation={navigation}  
                pagename={"Test"} 
                icon={require('../../../../assets/images/ic_gps.png')} 
                text={'Navigation'} 
                style={{flexDirection:'column',width:wp('30%'),height:hp('30%')}}
              ></Footer>
              <Footer   
                navigation={navigation} 
                icon={require('../../../../assets/images/ic_list.png')} 
                text={'Verification \nSlip'} 
                style={{flexDirection:'column' ,width:wp('30%'),height:hp('30%')}}
              ></Footer>
              <Footer 
                navigation={navigation}  
                icon={require('../../../../assets/images/ic_files.png')} 
                text={'3rd Party Form Details'} 
                style={{flexDirection:'column' ,width:wp('30%'),height:hp('30%')}}
              ></Footer>
              <Footer 
                navigation={navigation} 
                icon={require('../../../../assets/images/ic_photo.png')} 
                text={'Images'} 
                style={{flexDirection:'column' ,width:wp('30%'),height:hp('30%')}}
              ></Footer>
            </View> 
          </ScrollView>
        </View>
      </View>
      
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 10,
    justifyContent: 'center',
    paddingTop: (Platform.OS === 'ios') ? 20 : 0
  },
  text: {
    fontSize: 17,
    color: 'black',
    padding: 10
  },
  btnText: {
    textAlign: 'center',
    color: 'white',
    fontSize: 20
  },
  btnTextHolder: {
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.5)'
  },
  Btn: {
    padding: 10,
    backgroundColor: 'rgba(0,0,0,0.5)'
  },
  listontainer: {
    flex: 1,
    paddingTop: 2,
  },
  item: {
    flex:1, 
    fontSize: 18,
    height: 44,
  },
});