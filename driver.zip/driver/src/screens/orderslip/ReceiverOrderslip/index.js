import React, { Component } from 'react';
import { Text, View,Image, StyleSheet, LayoutAnimation, Platform, UIManager, TouchableOpacity,ScrollView, StatusBar, TextInput } from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import { ListItem, Card, Overlay } from 'react-native-elements';
import { FlatList } from 'react-native-gesture-handler';
import colors from '../../../utility/color';
import { CustomTextInputInfo, CustomText } from '../../../components/customview';


export default class ReceiverOrderSilp extends Component {
  constructor() {
    super();

    this.state = { expanded: false,isDropDown:false,isCity:false ,isState:false,isCountry:false,isPinCode:false,cityname:'Add City',statname:'Add State'}

    if (Platform.OS === 'android') {
      UIManager.setLayoutAnimationEnabledExperimental(true);
    }
  }
  getListViewItem = (item) => {  
    this.setState({ isCity:false});
    this.setState({cityname:item.key});
    }  
    getListViewItemState = (item) => {  
      this.setState({isState:false});
      this.setState({statname:item.key});
      }  
  changeLayout = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({ expanded: !this.state.expanded });
  }
  changeLayoutDropisCity = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    // this.setState({ isDropDown: !this.state.isDropDown });
    this.setState({ isCity: !this.state.isCity });

  }
  changeLayoutDropisState = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({ isState: !this.state.isState });

  }
  changeLayoutDropisCountry = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({ isCountry: !this.state.isCountry });

  }
  changeLayoutDropisPinCode= () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({ isPinCode: !this.state.isPinCode });

  }
 

  render() {
    const options = [
      {
        label: 'News'
      },
      {
        label: 'Design'
      },
      {
        label: 'Sales'
      },
      {
        label: 'Marketing'
      },
      {
        label: 'Customer Success'
      }
    ];
    const { value , onChangeValue } = this.props;

    return (
                              
      <View style={styles.container}>
        <View 
          style={{
            aspectRatio:5.1,
            flex:1,
            height:wp('18%'),
            borderWidth:1.2,
            borderColor:colors.WHITE_GREY,
            alignSelf:'center',
            flexDirection:'row',
            justifyContent:'space-between',
            marginTop:30
          }}
        >
          <Image 
            source={require('../../../../assets/images/ic_reciver_info.png')} 
            resizeMode='contain' 
            style={{flexDirection:'row',marginLeft:10,width:40,height:30,alignSelf:'center'}}
          ></Image>
          <Text style={{flexDirection:'row',fontSize:hp('2.3%'),fontFamily:'NunitoSans-Bold',alignSelf:'center'}}>Receiver Information</Text>
          <TouchableOpacity  onPress={this.changeLayout} style={{alignSelf:'center'}}>
            {this.state.expanded == false?      
              <Image 
                source={require('../../../../assets/images/ic_downn.png')} 
                resizeMode='contain' 
                style={{flexDirection:'row',width:40,height:40,right:10,alignSelf:'center'}}
              ></Image>
              :
              <Image 
                source={require('../../../../assets/images/ic_up.png')} 
                resizeMode='contain' 
                style={{width:40,height:40,right:10,alignSelf:'center'}}
              ></Image>
            } 
          </TouchableOpacity>
        </View>                  
        <View style={{ height: this.state.expanded ? null : 0, overflow: 'hidden' }}>
          <View style={{flexDirection:'column',marginLeft:10,marginTop:hp('3%')}}>
            <View style={{flexDirection:'row'}}>             
              <CustomText style={{fontSize:hp('2.1%'),color:colors.GREY,fontFamily:'NunitoSans-Light'}}>
                Name 
              </CustomText>
              <CustomText style={{fontSize:hp('2%'),fontFamily:'NunitoSans-Regular',color:colors.BLACK}}>
                :    Lorem Ipsum
              </CustomText>
            </View>
            <View style={{flexDirection:'row',marginTop:hp('1.5%')}}>
              <CustomText style={{fontSize:hp('2.1%'),color:colors.GREY,fontFamily:'NunitoSans-Light'}}>
                Address
              </CustomText>
              <CustomText style={{fontSize:hp('2%'),fontFamily:'NunitoSans-Regular',color:colors.BLACK}}>
                :  Lorem Ipsum
              </CustomText>      
            </View>
            <View style={{flexDirection:'row',marginTop:hp('1.5%')}}>
              <CustomText style={{fontSize:hp('2.1%'),color:colors.GREY,fontFamily:'NunitoSans-Light'}}>
                City
              </CustomText>
              <CustomText style={{fontSize:hp('2%'),fontFamily:'NunitoSans-Regular',color:colors.BLACK}}>
                :  Lorem Ipsum
              </CustomText>      
            </View>       
            <View style={{flexDirection:'row',marginTop:hp('1.5%')}}>
              <CustomText style={{fontSize:hp('2.1%'),color:colors.GREY,fontFamily:'NunitoSans-Light'}}>
                State
              </CustomText>
              <CustomText style={{fontSize:hp('2%'),fontFamily:'NunitoSans-Regular',color:colors.BLACK}}>
                :  Lorem Ipsum
              </CustomText>      
                        </View>
                              
                        <View style={{flexDirection:'row',marginTop:hp('1.5%')}}>
             <CustomText style={{fontSize:hp('2.1%'),color:colors.GREY,fontFamily:'NunitoSans-Light'}}>
              Country
             </CustomText>
             <CustomText style={{fontSize:hp('2%'),fontFamily:'NunitoSans-Regular',color:colors.BLACK}}>
               :  Lorem Ipsum
             </CustomText>      
            </View>                       
            <View style={{flexDirection:'row',marginTop:hp('1.5%')}}>
              <CustomText style={{fontSize:hp('2.1%'),color:colors.GREY,fontFamily:'NunitoSans-Light'}}>
                Pentode/Zip Code
              </CustomText>
              <CustomText style={{fontSize:hp('2%'),fontFamily:'NunitoSans-Regular',color:colors.BLACK}}>
                :  Lorem Ipsum
              </CustomText>      
            </View>
          </View>
        </View>      
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 10,
    justifyContent: 'center',
    paddingTop: (Platform.OS === 'ios') ? 20 : 0
  },

  text: {
    fontSize: 17,
    color: 'black',
    padding: 10
  },

  btnText: {
    // justifyContent:'space-between',
    textAlign: 'center',
    color: 'white',
    fontSize: 20
  },

  btnTextHolder: {
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.5)'
  },

  Btn: {
    padding: 10,
    backgroundColor: 'rgba(0,0,0,0.5)'
  },
  
  listontainer: {
    flex: 1,
    paddingTop: 2,
  
  },
  
  item: {
    flex:1,
    fontSize: 18,
    height: 44,
  },
  
});