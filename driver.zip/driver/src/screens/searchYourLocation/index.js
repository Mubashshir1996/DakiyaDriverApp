import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList,
    KeyboardAvoidingView,
    TouchableOpacity
} from 'react-native';
import { Icon, Avatar, Card } from 'react-native-elements'
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../utility/color';
import CustomText from '../../components/CustomText';
import CustomTextInput from '../../components/CustomTextInput';


function SearchYourLocation({navigation}){
    return(
        <KeyboardAvoidingView style={{flex:1}}>
            <StatusBar backgroundColor={colors.FONT_COLOR} />       
            <View style={styles.container}>
                <View style={styles.headerView}>
                    <TouchableOpacity onPress={() => navigation.goBack(null)}>
                        <Image 
                            source={require('../../../assets/images/ic_left_arrow.png')} 
                            resizeMode='contain' 
                            style={{width:wp('4.5%'),height:hp('5%'),marginLeft:wp('5%')}}
                        />
                    </TouchableOpacity>
                    <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignSelf:'center',marginRight:wp('11%')}}>
                        <CustomText style={styles.headerText}>Search for your location</CustomText>
                    </View>
                </View>
                <ScrollView style={{flex:1,flexDirection:'column'}} >
                    <View  style={{flexDirection:'column',marginTop:wp('5%')}}>
                        <View style={{flex:1,flexDirection:'row',marginLeft:wp('8%'),marginRight:wp('8%'),marginTop:wp('12%'),borderWidth:wp('0.4%'),borderRadius:wp('2%'),borderColor:colors.FONT_COLOR,height:wp('13.5%')}}>
                            <Image 
                                source={require('../../../assets/images/ic_search.png')} 
                                resizeMode='contain' 
                                style={{width:wp('6%'),height:hp('6%'),marginLeft:wp('4%'),alignSelf:'center'}}
                            ></Image>
                            <CustomTextInput placeholder='Location search' style={{fontFamily:'NunitoSans-Regular' ,position:'absolute',width:wp('75%'),marginLeft:wp('2.5%'),marginTop:wp('2%'),height:hp('6.8%'),fontSize:hp('1.9%'),color:colors.GREY,alignSelf:'center'}}></CustomTextInput>
                        </View>
                        <View style={{flexDirection:'column'}}>
                            <View style={{flexDirection:'row',marginTop:wp('12%')}}>
                                <View style={{width:wp('40%'),height:hp('0.5%'),backgroundColor:colors.FONT_COLOR,marginTop:wp('3.2%'),marginRight:wp('3%')}}/>
                                <CustomText style={{color:colors.FONT_COLOR,fontSize:wp('3.2%'),top:hp('1%'),fontFamily:'NunitoSans-Regular'}}>OR</CustomText>
                                <View style={{marginLeft:wp('2%'),marginTop:wp('3.2%'),width:wp('50%'),height:hp('0.5%'),backgroundColor:colors.FONT_COLOR}}/>
                            </View> 
                        </View> 
                        <View style={{ marginLeft:wp('5%'), flexDirection:'row',marginTop:wp('3%')}}>
                            <TouchableOpacity onPress={() => navigation.navigate('SaveLocationScreen')}>
                                <Image 
                                    source={require('../../../assets/images/ic_map.png')} 
                                    resizeMode='contain' 
                                    style={{width:wp('8%'),height:hp('8%')}}
                                ></Image>
                            </TouchableOpacity>
                            <View style={{flexDirection:'column',marginTop:wp('3%')}}>
                                <TouchableOpacity onPress={() => navigation.navigate('SaveLocationScreen')}>
                                    <CustomText style={{fontFamily:'NunitoSans-Regular',justifyContent:'center',marginLeft:wp('5%'),marginTop:wp('2.5%'),fontSize:hp('1.9%'),fontWeight:'bold'}}>Select location via map</CustomText> 
                                </TouchableOpacity>
                            </View>
                        </View>
                        <View style={{flexDirection:'column'}}>
                            <View style={{flexDirection:'row',marginTop:wp('1%')}}>
                                <View style={{width:wp('100%'),height:hp('1.5%'),backgroundColor:colors.FONT_COLOR,marginTop:wp('3.2%'),marginRight:wp('3%')}}/>
                            </View>
                        </View>
                        <View style={{flexDirection:'row',marginTop:wp('5%')}}>
                            <CustomText style={styles.addressHeader}>Recent Searches</CustomText> 
                        </View>
                        <View style={{ marginLeft:wp('10%'), flexDirection:'row',marginTop:wp('5%')}}>
                            <Image 
                                source={require('../../../assets/images/ic_time.png')} 
                                resizeMode='contain' 
                                style={{width:wp('8%'),height:hp('8%')}}
                            ></Image>
                            <View style={{flexDirection:'column',marginTop:wp('3%')}}>
                                <CustomText style={{justifyContent:'center',marginLeft:wp('5%'),fontSize:hp('1.9%'),fontFamily:'NunitoSans-Bold'}}>HOME</CustomText> 
                                <CustomText style={{justifyContent:'center',marginLeft:wp('5%'),marginTop:hp('1%'),fontSize:hp('1.4%'),fontFamily:'NunitoSans-Light'}}>Pune, Maharashtra, India</CustomText> 
                            </View>
                        </View>
                        <View style={{flexDirection:'row',marginTop:wp('5%')}}>
                            <CustomText style={styles.addressHeader}>Saved Addresses</CustomText> 
                        </View>
                        <View style={{ marginLeft:wp('10%'), flexDirection:'row',marginTop:wp('5%'),marginBottom:100}}>
                            <Image 
                                source={require('../../../assets/images/ic_homee.png')} 
                                resizeMode='contain' 
                                style={{width:wp('8%'),height:hp('8%')}}
                            ></Image>
                            <View style={{flexDirection:'column',marginTop:wp('3%')}}>
                                <CustomText style={{justifyContent:'center',marginLeft:wp('5%'),fontSize:hp('1.9%'),fontFamily:'NunitoSans-Bold'}}>OTHER</CustomText> 
                                <CustomText style={{justifyContent:'center',marginLeft:wp('5%'),marginTop:hp('1%'),fontSize:hp('1.4%'),fontFamily:'NunitoSans-Light'}}>Pune, Maharashtra, India</CustomText> 
                            </View>
                        </View>       
                    </View>
                </ScrollView>
            </View>
        </KeyboardAvoidingView>  
      )

}

const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column'
    },
    headerView:{
        flexDirection:'row',
        marginTop:hp('5%')
    },
    headerText:{
        marginLeft:wp('6%'),
        fontSize:hp('3%'),
        color:colors.FONT_COLOR,
        fontFamily:'NunitoSans-Bold'
    },
    contentView:{
        flexDirection:'row',
        marginTop:hp('4%'),
        alignSelf:'center'
    },
    contentText:{
        fontSize:wp('5%'),
        color:colors.BLACK
    },
    addressHeader:{
        marginLeft:wp('5%'),
        fontSize:hp('2%'),
        fontWeight:'bold',
        color:colors.BLACK,
        fontFamily:'NunitoSans-Regular'
    }
  
})

export default SearchYourLocation;