import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList
  } from 'react-native';
import CustomText from '../../../components/CustomText';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../utility/color';
import { Card, ListItem } from 'react-native-elements';
import ListOrderH from '../../../components/ListOrderH';
import Orderhistoryitem from '../../../components/ListItemHistory';

  function AcceptedOrder({navigation}){
   function renderSeparator() {  
      return (  
          <View  
              style={{  
                  height: 1,  
                  width: "100%",  
                  backgroundColor: "#000",  
              }}  
          />  
      );  
    };  
    return(
        <View style={styles.container}>
    
            <StatusBar backgroundColor={colors.FONT_COLOR} />
                <ScrollView>
                    <View style={styles.headerView}>
                        <CustomText style={styles.headerText}>Accepted Order</CustomText>
                    </View>
   
                    <View style={styles.contentView}>


                        <View style={{flex:1,flexDirection:'row',marginTop:hp('5%')}}>
                            <FlatList
                                nestedScrollEnabled={true}
                                contentContainerStyle={{ paddingBottom: wp('20%')}}

                                style={{backgroundColor:'transparent'}}
                                    data={[  
                                        {key: 'Indore To Mumbai'},
                                        {key: 'Indore To Mumbai'}, 
                                        {key: 'Indore To Mumbai'},
                                        {key: 'Indore To Bhopal'},  
                                        {key: 'Indore To Bhopal'},
                                        {key: 'Indore To Bhopal'},
                                        {key: 'Indore To Bhopal'},                                 
                                        {key: 'Indore To Bhopal'},  
                                        {key: 'Indore To Bhopal'}, 
                                        {key: 'Indore To Bhopal'}, 
                                        {key: 'Indore To Bhopal'}, 
                                        {key: 'Indore To Bhopal'}, 
                                        {key: 'Indore To Bhopal'}, 
                                        {key: 'Indore To Bhopal'}, 
                                        {key: 'Indore To Bhopal'}, 
                                        {key: 'Indore To Bhopal'}, 
                                        {key: 'Indore To Bhopal'}, 
                                        {key: 'Indore To Bhopal'}, 
                                        {key: 'Indore To Bhopal'},  
                                        {key: 'Indore To Bhopal'}, 
                                    ]}   
                                    renderItem={({item}) =>  
                                        <View >

                                            <Orderhistoryitem data={item} />
                                        </View>
                                    }   
                            >
                            </FlatList> 
                        </View>
                    </View>
                </ScrollView>
        </View>

    )
}
 const styles = StyleSheet.create({
 container:{
   flex:1,
   flexDirection:'column',
    backgroundColor:colors.WHITE
  
 },headerView:{
   flexDirection:'row',
   backgroundColor:colors.WHITE,
   height:wp('15%'),
   justifyContent:'center',
},headerText:{
  alignSelf:'center',
  fontSize:hp('3.2%'),
  color:colors.FONT_COLOR,
 fontFamily:'NunitoSans-Bold',
    marginTop:wp('20%')
},contentView:{

  marginTop:wp('15%'),
  flexDirection:'column',
  backgroundColor:'transparent',
    // height:hp('100%')
  },contentViews:{
    marginLeft:'2%',
    marginRight:'2%',
    backgroundColor:'transparent',
  },insideCardStyle:{
    color:colors.FONT_COLOR
  }
 });
  export default AcceptedOrder;
  