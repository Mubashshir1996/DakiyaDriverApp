import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList
  } from 'react-native';
import CustomText from '../../../components/CustomText';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../utility/color';





  function AboutusScreen({navigation}){
      return(
          <View style={{flex:1}}>
            <StatusBar backgroundColor={colors.FONT_COLOR} />
            <ScrollView>
                <View style={styles.container}>
                    <View style={styles.headerView}>
                        <CustomText style={styles.headerText}>About Us</CustomText>
                    </View>
                    <View style={{flexDirection:'column'}}>
                        <View style={styles.contentView}>
                            <CustomText style={styles.contentText}>Details About us</CustomText>
                        </View>
                        <View style={styles.contentView}>
                            <CustomText style={styles.contentText}>Contact Information</CustomText>
                        </View>
                        <View style={styles.contentView}>
                            <CustomText style={styles.contentText}>Feedback & Rating</CustomText>
                        </View>
                        <View style={styles.contentView}>
                            <CustomText style={styles.contentText}>App Services</CustomText>
                        </View>
                        <View style={styles.contentView}>
                            <CustomText style={styles.contentText}>Terms & Conditions</CustomText>
                        </View>
                        <View style={styles.contentView}>
                            <CustomText style={styles.contentText}>Privacy Policy</CustomText>
                        </View>
                    </View>
                </View>
            </ScrollView>
        </View>
    )
}

const styles = StyleSheet.create({
   container:{
       flex:1,
       flexDirection:'column',
       paddingBottom:wp('10%')
   },headerView:{
       flexDirection:'row',
       justifyContent:'center',
       marginTop:hp('7%')
   },headerText:{
       alignSelf:'center',
       fontSize:hp('3%'),
       color:colors.FONT_COLOR,
       fontFamily:'NunitoSans-Bold'
   },contentView:{
       flexDirection:'column',
       marginTop:hp('5%'),
       marginLeft:wp('10%'),
       backgroundColor:colors.WHITE_GREY
       ,padding:wp('4%')
       ,marginRight:wp('10%')
   },contentText:{
    fontSize:hp('2%'),
    fontFamily:'NunitoSans-Regular',
    color:colors.BLACK
    ,marginLeft:wp('3%')
   
   }
   ,secontentView:{
    flexDirection:'column'
    ,padding:wp('4%')
    ,marginRight:wp('10%')
    }
   
});



export default AboutusScreen;

