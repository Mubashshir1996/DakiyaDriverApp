import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList
} from 'react-native';
import CustomText from '../../../components/CustomText';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../utility/color';
import { Card, ListItem } from 'react-native-elements';
import ListOrderH from '../../../components/ListOrderH';
import Orderhistoryitem from '../../../components/ListItemHistory';

function JobHistoryScreen({navigation}){
    function renderSeparator() {  
        return (  
            <View  
                style={{  
                    height: 1,  
                    width: "100%",  
                    backgroundColor: "#000",  
                }}  
            />  
        );  
    };  
    return(
        <View style={styles.container}>
            <StatusBar backgroundColor={colors.FONT_COLOR} />
            <ScrollView>
                <View style={styles.headerView}>
                    <CustomText style={styles.headerText}>Job History</CustomText>
                </View>
                <View style={styles.contentView}>
                    <View style={{marginLeft:20,marginRight:20,borderRadius:5,flex:1,flexDirection:'row',height:hp('10%'),backgroundColor:colors.FONT_COLOR,justifyContent:'space-between'}}>
                        <View style={{alignSelf:'center',justifyContent:'center',width:wp('30%'),borderRadius:5,marginLeft:wp('2%'),backgroundColor:colors.WHITE, flexDirection:'row',height:hp('8%')}}>
                            <CustomText style={{alignSelf:'center',marginLeft:wp('2%'),fontSize:hp('2.3%'),fontFamily:'NunitoSans-Bold'}}>Accept</CustomText> 
                        </View>
                        <View style={{flexDirection:'row',height:hp('10%'),alignSelf:'center'}}>
                            <CustomText style={{marginLeft:wp('5%'),marginTop:hp('3%'),fontSize:hp('2.5%'),fontFamily:'NunitoSans-Bold',right:wp('15%'),color:colors.WHITE}}>All</CustomText> 
                        </View>
                    </View>
                    <View style={{flex:1,flexDirection:'row',marginTop:hp('5%')}}>
                        <FlatList
                            nestedScrollEnabled={true}
                            contentContainerStyle={{ paddingBottom: wp('20%')}}
                            style={{backgroundColor:'transparent'}}
                            data={[  
                                {key: 'Indore To Mumbai'},
                                {key: 'Indore To Mumbai'}, 
                                {key: 'Indore To Mumbai'},
                                {key: 'Indore To Bhopal'},  
                                {key: 'Indore To Bhopal'},
                                {key: 'Indore To Bhopal'},
                                {key: 'Indore To Bhopal'},
                                {key: 'Indore To Bhopal'},  
                                {key: 'Indore To Bhopal'}, 
                                {key: 'Indore To Bhopal'}, 
                                {key: 'Indore To Bhopal'}, 
                                {key: 'Indore To Bhopal'}, 
                                {key: 'Indore To Bhopal'}, 
                                {key: 'Indore To Bhopal'}, 
                                {key: 'Indore To Bhopal'}, 
                                {key: 'Indore To Bhopal'}, 
                                {key: 'Indore To Bhopal'}, 
                                {key: 'Indore To Bhopal'}, 
                                {key: 'Indore To Bhopal'},  
                                {key: 'Indore To Bhopal'} 
                            ]}   
                            renderItem={({item}) =>  
                                <View >
                                    <Orderhistoryitem data={item} />
                                </View>
                            }
                        >
                        </FlatList> 
                    </View>
                </View>
            </ScrollView>
        </View>

    )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column',
        backgroundColor:colors.WHITE 
    },
    headerView:{
        flexDirection:'row',
        backgroundColor:colors.WHITE,
        height:wp('15%'),
        justifyContent:'center',
    },
    headerText:{
        alignSelf:'center',
        fontSize:hp('3.2%'),
        color:colors.FONT_COLOR,
        fontWeight:'bold',
        marginTop:wp('20%')
    },
    contentView:{
        marginTop:wp('15%'),
        flexDirection:'column',
        backgroundColor:'transparent'
    },
    contentViews:{
        marginLeft:'2%',
        marginRight:'2%',
        backgroundColor:'transparent'
    },
    insideCardStyle:{
        color:colors.FONT_COLOR
    }
});

 export default JobHistoryScreen;
  