import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList,
    KeyboardAvoidingView,
    TouchableOpacity
  } from 'react-native';
import { Icon, Avatar, Card } from 'react-native-elements'

import CustomText from '../../../components/CustomText';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../utility/color';
import InputBoxImage from '../../../components/inputBoxImage';
import { FullButtonComponent } from '../../../components/customview';
import { GenericStyles } from '../../otp/GenericStyles';
import WalletlistItem from '../../../components/WalletlistItem';

function WalletScreen({navigation}){

    return(
        <KeyboardAvoidingView style={{flex:1}}>
            <StatusBar backgroundColor={colors.FONT_COLOR} />
        
            <View style={styles.container}>
                <View style={styles.headerView}>
                    <TouchableOpacity onPress={() => navigation.goBack(null)}>
                        <Image source={require('../../../assets/ic_left_arrow.png')} resizeMode='contain' style={{width:wp('4.5%'),height:hp('5%'),marginLeft:wp('5%')}}/>
                    </TouchableOpacity>
                    <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignSelf:'center',marginRight:wp('11%')}}>
                        <CustomText style={styles.headerText}>Wallet</CustomText>
                    </View>

       
                </View>
        
                <View style={{flex:1,flexDirection:'column'}}>
         
                    <View style={{justifyContent:'center',alignSelf:'center',flexDirection:'column',aspectRatio:3.8,marginTop:hp('5%'),height:hp('11%'),borderColor:colors.FONT_COLOR,borderWidth:1}}>
                        <CustomText style={{alignSelf:'center',fontSize:hp('2.5%'),fontFamily:'NunitoSans-Bold',color:colors.BLACK}}>Aailable Balance</CustomText>
                         <CustomText style={{alignSelf:'center',fontSize:hp('2.25%'),fontFamily:'NunitoSans-Bold',color:colors.FONT_COLOR}}>₹ 1500.0</CustomText>
                    </View>

        
                    <FlatList
                        contentContainerStyle={{paddingBottom: wp('30%')}}

                        style={{backgroundColor:'transparent'}}
                        data={[  
                                {name: 'Lorem Ipsum',time:'12.01 PM',amount:'-₹ 3,000',amount_status:'low'},
                                {name: 'Lorem Ipsum',time:'12.01 PM',amount:'-₹ 3,000',amount_status:'low'},
                                {name: 'Lorem Ipsum',time:'12.01 PM',amount:'+₹ 3,000',amount_status:'high'},
                                {name: 'Lorem Ipsum',time:'12.01 PM',amount:'-₹ 3,000',amount_status:'low'},
                                {name: 'Lorem Ipsum',time:'12.01 PM',amount:'+₹ 3,000',amount_status:'high'},
                                {name: 'Lorem Ipsum',time:'12.01 PM',amount:'-₹ 3,000',amount_status:'low'}
      
                            ]}  
                        renderItem={({item}) =>  
                            <View style={styles.contentViews}>
    
                                <WalletlistItem data={item} navigation={navigation}/>
                            </View>
                        }   
                    >
                    </FlatList>
                </View>
            </View>
        </KeyboardAvoidingView>
    )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column'
    },headerView:{
        flexDirection:'row',
        marginTop:hp('5%')
    },headerText:{
      fontSize:hp('3%'),
       fontFamily:'NunitoSans-Bold',
        color:colors.FONT_COLOR,
        fontWeight:'bold'
    },contentView:{
        flexDirection:'row',
        marginTop:hp('4%'),
        alignSelf:'center'
    },contentText:{
     fontSize:hp('2%'),
     color:colors.BLACK,
    },addressHeader:{
      marginLeft:wp('5%'),
      fontSize:wp('5.2%'),
      fontWeight:'bold',
      color:colors.BLACK,
    } ,submitButtonText: {
      color: colors.WHITE,
      fontSize:17,
    },contentViews:{

    }
  
})
export default WalletScreen;