import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList,
    KeyboardAvoidingView,
    TouchableOpacity
  } from 'react-native';
import { Icon, Avatar, Card } from 'react-native-elements'

import CustomText from '../../../commonview/CustomText';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../../utilty/color';
import InputBoxImage from '../../../commonview/inputBoxImage';
import { FullButtonComponent } from '../../../commonview/customview';
import { GenericStyles } from '../../otp/GenericStyles';
import TextBoxImage from '../../../commonview/TextBoxImage';

  
  function ProfileScreen({navigation}){

    return(
        <KeyboardAvoidingView style={{flex:1}}>
            <StatusBar backgroundColor={colors.FONT_COLOR} />
      
            <View style={styles.container}>
                <View style={styles.headerView}>
                    <TouchableOpacity onPress={() => navigation.goBack(null)}>
                        <Image source={require('../../../assets/ic_left_arrow.png')} resizeMode='contain' style={{width:wp('4.5%'),height:hp('5%'),marginLeft:wp('5%')}}/>
                    </TouchableOpacity>
                    <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignSelf:'center',marginRight:wp('11%')}}>
                        <CustomText style={styles.headerText}>Profile</CustomText>
                    </View>
                </View>
                <ScrollView style={{flex:1,flexDirection:'column'}} >
                    {/* Start Content View */}
                    <View  style={{flex:1,flexDirection:'column'}}>
     
                        {/* Profle pic Section */}
                        <View style={styles.contentView}>
                            <View style={{flex:1,flexDirection:'row',aspectRatio:1.5,height:hp('35%'),elevation:0,alignSelf:'center',justifyContent:'center',borderRadius:wp('2%')}}>
                                {/* <Card containerStyle={{width:wp('65%'),height:hp('35%'),elevation:0,alignSelf:'center',justifyContent:'center',borderRadius:wp('2%')}}> */}
                                <View style={{aspectRatio:1.5,position:'relative', flex:1,flexDirection:'row',alignSelf:'center',justifyContent:'center',borderRadius:15}}>
                                    <Image  source={require('../../../assets/ic_avtarr.png')} resizeMode='contain' style={{aspectRatio:1,width:wp('65%'),height:hp('65%'),alignSelf:'center',borderRadius:wp('0.5%')}}></Image>
                                    {/* <View style={{flex:1,flexDirection:'column',left:wp('73%'),position:'absolute',backgroundColor:colors.FONT_COLOR,width:60,height:60,justifyContent:'center',borderRadius:wp('10%'),alignItems:'flex-end',top:'85%',marginBottom:10}}>
                                    <Image  source={require('../../../assets/ic_edit.png')} resizeMode='contain' style={{position:'absolute',tintColor:'white',width:wp('6%'),height:hp('6%'),borderRadius:2,alignSelf:'center'}}></Image>
                                    </View>  */}
                                </View>
                                 {/* </Card> */} 
                            </View>
                        </View>
      
                        {/* Fields View */}
                        <View style={{flexDirection:'column',flex:1,marginTop:hp('2%')}}>
                            <View style={{flexDirection:'row',marginRight:hp('4%')}}>
                                <TextBoxImage rightInput={wp('3%')} inputFontSize={hp('1.9%')} levelfontSize={hp('1.9%')} fontFamily='NunitoSans-Regular' leftMar={wp('5%')} type={1} width={wp('8%')} height={hp('8%')} name='Name' placename='Lorem Ipsum' path={require('../../..//assets/ic_name.png')}/>
      
                            </View>
                            <View style={{flexDirection:'row',marginTop:hp('1.5%'),marginRight:wp('4%')}}>
                                <TextBoxImage rightInput={wp('3%')} inputFontSize={hp('1.9%')} levelfontSize={hp('1.9%')} fontFamily='NunitoSans-Regular' leftMar={wp('5%')} type={1} width={wp('8%')} height={hp('8%')}  name='Phone' placename='Lorem Ipsum' path={require('../../..//assets/ic_phone.png')}/>
      
                            </View>
                            <View style={{flexDirection:'row',marginTop:hp('1.5%'),marginRight:wp('4%')}}>
                                <TextBoxImage rightInput={wp('3%')} inputFontSize={hp('1.9%')} levelfontSize={hp('1.9%')} fontFamily='NunitoSans-Regular' leftMar={wp('5%')} type={1} width={wp('8%')} height={hp('8%')}  name='Email' placename='Lorem Ipsum' path={require('../../..//assets/ic_email.png')}/>
      
                            </View>
                            <View style={{flexDirection:'row',marginRight:wp('4%')}}>
                                <TextBoxImage rightInput={wp('3%')} inputFontSize={hp('1.9%')} levelfontSize={hp('1.9%')} fontFamily='NunitoSans-Regular' leftMar={wp('5%')} type={1} width={wp('8%')} height={hp('8%')} name='Description' placename='Lorem Ipsum' path={require('../../..//assets/ic_calendar.png')}/>
                            </View>
                            <View style={{marginRight:40,marginLeft:40,marginTop:50,marginBottom:40}}>
     
                                <TouchableOpacity onPress={() => navigation.navigate('WalletScreen')}>
      
                                    <View style={{borderRadius:10,justifyContent:'center',backgroundColor:colors.FONT_COLOR,flex:1,flexDirection:'row',width:wp('75%'),alignSelf:'center',justifyContent:'center',height:hp('8%')}}>
                                        <Image source={require('../../../assets/ic_wallet.png')} resizeMode='contain' style={{width:wp('6.5%'),height:hp('6.5%'),alignSelf:'center'}}></Image>
                                            <CustomText style={{fontSize:hp('2.4%'),fontFamily:'NunitoSans-Regular',alignSelf:'center',marginLeft:wp('5%'),color:colors.WHITE}}>Wallet</CustomText>
                                    </View>
                                </TouchableOpacity>
                                {/* <FullButtonComponent
                                type={'fill'}
                                text={'Submit'}
                                textStyle={styles.submitButtonText}
                                buttonStyle={GenericStyles.mt24}
                                />  */}
                            </View>
                        </View>
                    </View>     
                </ScrollView>
             </View>
       </KeyboardAvoidingView>

    )
}
  const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column'
    },headerView:{
        flexDirection:'row',
        marginTop:hp('5%')
    },headerText:{
      fontSize:hp('3%'),
       fontFamily:'NunitoSans-Bold',
        color:colors.FONT_COLOR,
        fontWeight:'bold'
    },contentView:{
        flexDirection:'row',
        marginTop:hp('4%'),
        alignSelf:'center'
    },contentText:{
     fontSize:wp('5%'),
     color:colors.BLACK,
    },addressHeader:{
      marginLeft:wp('5%'),
      fontSize:wp('5.2%'),
      fontWeight:'bold',
      color:colors.BLACK,
    } ,submitButtonText: {
      color: colors.WHITE,
      fontSize:hp('3%'),
    }
  
})
export default ProfileScreen;
  