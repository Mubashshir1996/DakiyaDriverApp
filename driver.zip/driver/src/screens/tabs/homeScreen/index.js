import React  from 'react';
import {
  StyleSheet,
  View,
  Text,
  StatusBar,
  Image,
  ScrollView,
  TouchableOpacity,
  FlatList
} from 'react-native';
import colors from '../../../utility/color';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import CustomText from '../../../components/CustomText';
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import ListOrderH from '../../../components/ListOrderH';



function HomeScreen ({ navigation}){
    var navigation = navigation
    return (
        <ScrollView   removeClippedSubviews={false}>
            <View style={styles.container}>
                <StatusBar backgroundColor={colors.FONT_COLOR} />
                <View style={{flex:0.13}}>
                    <View style={styles.box1}>
                        <View style={{flex:1,flexDirection:'row',marginTop:wp('2%')}}>
                            <TouchableOpacity onPress={() => navigation.navigate('SearchYourLocation')}>
                                <Image
                                    source={require('../../../assets/pin.png')}
                                    resizeMode='contain'
                                    style={{width:wp('5.1%'),height:hp('5.1%'),justifyContent:'center',marginTop:hp('2.2%'),marginLeft:20}}
                                />
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => navigation.navigate('SearchYourLocation')}>
                                <View style={{flexDirection:'column',marginLeft:12,marginTop:hp('2.5%')}}>
                                    <Text style={{color:colors.WHITE,fontSize:hp('1.4%')}}>YourLocation....</Text>
                                    <View style={{flexDirection:'row'}}>
                                        <Text style={{color:colors.WHITE,fontSize:hp('2%'),fontWeight:'800'}}>Bangalor</Text>
                                        <Image 
                                            source={require('../../../assets/ic_down.png')} 
                                            resizeMode='contain' 
                                            style={{width:35,height:35,bottom:hp('0.8%')}}
                                        />
                                    </View>
                                </View>
                            </TouchableOpacity>
                            <View style={{flex:1,flexDirection:'row',justifyContent:'flex-end',margin:20}}>
                                <TouchableOpacity onPress={() => navigation.navigate('ProfileScreen')}>
                                    <Image 
                                        source={require('../../../assets/ic_user.png')} 
                                        resizeMode='contain' 
                                        style={{width:wp('5.5%'),height:hp('5.5%')}} 
                                    />
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => navigation.navigate('NotificationScreen')}>
                                    <Image 
                                        source={require('../../../assets/bell.png')} 
                                        resizeMode='contain' 
                                        style={{width:wp('5.5%'),height:hp('5.5%'),marginLeft:15}} 
                                    />
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View> 
                </View>
                <View style={{flex:1,flexDirection:'column',height:hp('10%')}}>
                    <View style={{flexDirection:'row',height:hp('10%'),justifyContent:'space-between'}}>
                        <CustomText 
                            style={{marginLeft:wp('5%'),marginTop:hp('3%'),fontSize:hp('2.5%'),fontFamily:'NunitoSans-Bold'}}
                        >
                            List of Open Job
                        </CustomText> 
                        <View style={{alignSelf:'center' ,padding:wp('2%')}}> 
                            <TouchableOpacity onPress={() => navigation.navigate('FilterScreen')} >
                                <Image 
                                    source={require('../../../assets/ic_filter.png')} 
                                    resizeMode='contain' 
                                    style={{alignSelf:'center',justifyContent:'center',padding:wp('4.5%'),width:wp('1%'),height:hp('1%'),right:wp('5%')}}
                                ></Image>
                            </TouchableOpacity>
                        </View>
                    </View>
                    <View style={{flex:1,flexDirection:'row',marginTop:5}}>
                        <FlatList
                            nestedScrollEnabled={true}
                            contentContainerStyle={{ paddingBottom: wp('20%')}}
                            style={{backgroundColor:'transparent'}}
                            data={[  
                                    {key: 'Indore To Mumbai'},
                                    {key: 'Indore To Mumbai'}, 
                                    {key: 'Indore To Mumbai'},
                                    {key: 'Indore To Mumbai'}, 
                                    {key: 'Indore To Mumbai'},
                                    {key: 'Indore To Mumbai'}, 
                                ]}   
                            renderItem={({item}) =>  
                                <View >
                                    <ListOrderH navigation={navigation} data={item.key} />
                                </View>
                            }   
                        >
                        </FlatList> 
                    </View>
                </View> 
            </View>
        </ScrollView>  
    );
}

const styles = StyleSheet.create({
    wrapper: {
        justifyContent:'center',
    },
    container: {
        height: hp('100%'),
        display: 'flex',
        flexDirection: 'column'
    },
    box1: {
        flex:1,
        width: wp('100%'),
        height:hp('5%'),
        backgroundColor: colors.FONT_COLOR
    },
    box2: {
        justifyContent:'center',
        alignSelf:'center',
        flex:1,
        flexDirection:'row', 
        position: 'absolute',
        top:hp('15%')
    ,   borderRadius:wp('5%'),
        alignSelf:'center'
    },
    box3: {
        position: 'absolute',
        top: 120,
        left: 120,
        width: 100,
        height: 100,
        backgroundColor: 'green'
    },
    text: {
        color: '#ffffff',
        fontSize: 80
    }, 
    slide1: {
        flex:1,
        alignSelf:'center',
        borderRadius:wp('5%'),
        flexDirection:'row',
    },
    slide2: {
        flex:1,
        alignSelf:'center',
        borderRadius:wp('5%'),
        flexDirection:'row',
    },
    slide3: {
        flex:1,
        alignSelf:'center',
        borderRadius:wp('5%'),
        flexDirection:'row',
    },
    slide4: {
        flex:1,
        alignSelf:'center',
        borderRadius:wp('5%'),
        flexDirection:'row',
    },
    text: {
        color: colors.FONT_COLOR,
        fontSize: 30,
        fontWeight: 'bold',
        marginTop:'20%',
        alignSelf:'center',
        alignItems:'center'
    },
    des_text: {
        color: colors.FONT_COLOR,
        fontSize: 18,
        fontWeight: 'bold',
        marginTop:'20%',
        alignSelf:'center',
        alignItems:'center'
    },
    slide1_view:{
        flexDirection:'column',
        marginLeft:'10%'
    },
    contentViews:{
        flexDirection:'row',
        justifyContent:'center',
        alignSelf:'center',
        backgroundColor:'transparent',
        height:hp('25%')
    },
    insideCardStyle:{
        color:colors.FONT_COLOR
    }
});

export default HomeScreen; 