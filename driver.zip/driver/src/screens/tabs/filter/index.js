import React, { useState }  from 'react';
import {
  StyleSheet,
  View,
  Text,
  StatusBar,
  Image,
  ScrollView,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
} from 'react-native';
import colors from '../../../utility/color';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import CustomText from '../../../components/CustomText';
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import { CheckBox } from 'react-native-elements';
import { CustomTextInput, FullButtonComponent } from '../../../components/customview';
import InputBoxImage from '../../../components/inputBoxImage';
import { GenericStyles } from '../../otp/GenericStyles';



export function FilterScreen({navigation}){
    const [isSelected, setSelection] = useState(false);

    return(
        <KeyboardAvoidingView style={{flex:1}}>
            <StatusBar backgroundColor={colors.FONT_COLOR} />
            <View style={styles.container}>
                <View style={styles.headerView}>
                    <TouchableOpacity onPress={() => navigation.goBack(null)}>
                        <Image 
                            source={require('../../../../assets/ic_left_arrow.png')} 
                            resizeMode='contain' 
                            style={{width:wp('4.5%'),height:hp('5%'),marginLeft:wp('5%')}}
                        />
                    </TouchableOpacity>
                    <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignSelf:'center'}}>
                        <CustomText style={styles.headerText}>Filters</CustomText>
                    </View>
                </View>
                <ScrollView>
                    <View style={styles.contentView}>
                        <CustomText style={{color:colors.FONT_COLOR,fontSize:hp('2%'),fontFamily:'NunitoSans-Bold',marginTop:hp('5%')}}>CURRENT LOCATION</CustomText>
                        <View style={{flexDirection:'row'}}>
                            <CheckBox
                                containerStyle={{backgroundColor:'transparent',right:wp('5%'),marginTop:hp('3%')}} 
                                size={30}
                                textStyle={{color:colors.FONT_COLOR,fontSize:hp('1.9%'),fontFamily:'NunitoSans-Regular',left:wp('2%')}}
                                title='Select Current location'
                                checkedColor={colors.FONT_COLOR}
                                checked={isSelected}
                                onPress={() => isSelected == false  ? (setSelection(true)):(setSelection(false))  }
                            />
                        </View>
                        <CustomText style={{color:colors.FONT_COLOR,fontSize:hp('2%'),fontFamily:'NunitoSans-Bold',marginTop:hp('5%')}}>RANGE</CustomText>
                        <View style={{flexDirection:'row',marginRight:wp('4%')}}>
                            <InputBoxImage  
                                type={1}  
                                inputFontSize={hp('1.9%')} 
                                keyboardType={'default'} 
                                returnKeyType={'next'} 
                                leftMar={wp('4%')}  
                                width={wp('8%')} 
                                height={wp('8%')}  
                                name='Name' 
                                placename='Select Range' 
                                path={require('../../../../assets/ic_plus.png')} 
                                right={wp('8%')} 
                                rightInput={wp('3%')} 
                                placeholderColor={colors.FONT_COLOR}
                            />
                        </View>
                        <CustomText style={{color:colors.FONT_COLOR,fontSize:hp('2%'),fontFamily:'NunitoSans-Bold',marginTop:hp('5%')}}>CATEGORY</CustomText>
                        <View style={{flexDirection:'row',marginRight:wp('4%')}}>
                            <InputBoxImage  
                                type={1}  
                                inputFontSize={hp('1.9%')} 
                                keyboardType={'default'} 
                                returnKeyType={'next'} 
                                leftMar={wp('4%')} 
                                width={wp('8%')} 
                                height={wp('8%')}  
                                name='Name' 
                                placename='Add Category' 
                                path={require('../../../../assets/ic_plus.png')} 
                                right={wp('8%')}  
                                rightInput={wp('3%')} 
                                placeholderColor={colors.FONT_COLOR}
                            />
                        </View>
                        <CustomText style={{color:colors.FONT_COLOR,fontSize:hp('2%'),fontFamily:'NunitoSans-Bold',marginTop:hp('5%')}}>SIZE</CustomText>
                        <View style={{flexDirection:'row',marginRight:wp('4%')}}>
                            <InputBoxImage  
                                type={1}  
                                inputFontSize={hp('1.9%')} 
                                keyboardType={'default'} 
                                returnKeyType={'next'} 
                                leftMar={wp('4%')}  
                                width={wp('8%')} 
                                height={wp('8%')}  
                                name='Name' 
                                placename='Add Category' 
                                path={require('../../../../assets/ic_plus.png')} 
                                right={wp('8%')} 
                                rightInput={wp('3%')} 
                                placeholderColor={colors.FONT_COLOR}
                            />
                        </View>
                        <View style={{paddingBottom:wp('30%'),marginTop:30,marginRight:wp('11%')}}>
                            <FullButtonComponent
                                type={'fill'}
                                text={'Apply'}
                                textStyle={styles.submitButtonText}
                                buttonStyle={GenericStyles.mt24}
                            />
                        </View>         
                    </View>
                </ScrollView>
            </View>
        </KeyboardAvoidingView>        

    )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column'
    },
    headerView:{
        flexDirection:'row',
        marginTop:hp('5%')
    },
    headerText:{
        justifyContent:'center',
        alignSelf:'center',
        fontSize:hp('3%'),
        color:colors.FONT_COLOR,
        fontFamily:'NunitoSans-Bold'
    },
    contentView:{
        flex:1,
        flexDirection:'column',
        marginTop:hp('4%'),
        marginLeft:wp('6.5%')
    },
    contentText:{
        fontSize:wp('5%'),
        color:colors.BLACK
    },
    checkbox: {
        alignSelf: "center",
        borderRadius:5,
        padding:50
    },
    submitButtonText: {
        color: colors.WHITE,
        fontSize:hp('2.4%')
    }
})