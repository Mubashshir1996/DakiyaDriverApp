import React, { Component } from 'react';
import { 
    Text, 
    View,Image, 
    StyleSheet, 
    LayoutAnimation, 
    Platform, 
    UIManager, 
    TouchableOpacity,
    ScrollView, 
    StatusBar, 
    TextInput 
} from 'react-native';
import colors from '../../../utility/color';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import CustomTextInputInfo from '../../../components/CustomTextInputInfo';
import CustomText from '../../../components/CustomText';
import { ListItem, Card, Overlay } from 'react-native-elements';
import { FlatList } from 'react-native-gesture-handler';






export default class ReceiverInfomation extends Component {
    constructor() {
        super();

        this.state = { expanded: false,isDropDown:false,isCity:false ,isState:false,isCountry:false,isPinCode:false,cityname:'Add City',statname:'Add State'}

        if (Platform.OS === 'android') {
            UIManager.setLayoutAnimationEnabledExperimental(true);
        }
    }
    getListViewItem = (item) => {  
        this.setState({ isCity:false});
        this.setState({cityname:item.key});
    }  
    getListViewItemState = (item) => {  
        this.setState({isState:false});
        this.setState({statname:item.key});
    }  
    changeLayout = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ expanded: !this.state.expanded });
    }
    changeLayoutDropisCity = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        // this.setState({ isDropDown: !this.state.isDropDown });
        this.setState({ isCity: !this.state.isCity });
    }
    changeLayoutDropisState = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ isState: !this.state.isState });
    }
    changeLayoutDropisCountry = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ isCountry: !this.state.isCountry });
    }
    changeLayoutDropisPinCode= () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ isPinCode: !this.state.isPinCode });
    }
 

    render() {
        const options = [
        {
            label: 'News'
        },
        {
            label: 'Design'
        },
        {
            label: 'Sales'
        },
        {
            label: 'Marketing'
        },
        {
            label: 'Customer Success'
        }
        ];
        const { value , onChangeValue } = this.props;

        return (
            <View style={styles.container}>
                {/* <View  style={{justifyContent:'space-between',flex:1,flexDirection:'column'}} > */}
        
                <View 
                    style={{
                        aspectRatio:5.1,
                        flex:1,height:wp('18%'),
                        borderWidth:1.2,
                        borderColor:colors.WHITE_GREY,
                        alignSelf:'center',
                        flexDirection:'row',
                        justifyContent:'space-between',
                        marginTop:30
                    }}
                >
                    <Image 
                        source={require('../../../assets/ic_reciver_info.png')} 
                        resizeMode='contain' 
                        style={{
                            flexDirection:'row',
                            marginLeft:10,width:40,
                            height:30,alignSelf:'center'
                        }}
                    ></Image>
                    <Text 
                        style={{
                            flexDirection:'row',
                            fontSize:hp('3%'),
                            alignSelf:'center'
                        }}
                    >
                        Receiver Information
                    </Text>
                    <TouchableOpacity  onPress={this.changeLayout} style={{alignSelf:'center'}}>
                        {this.state.expanded == false?      
                            <Image 
                                source={require('../../../assets/ic_downn.png')} 
                                resizeMode='contain' 
                                style={{
                                    flexDirection:'row',
                                    width:40,
                                    height:40,
                                    right:10,
                                    alignSelf:'center'
                                }}
                            ></Image>
                        :
                            <Image 
                                source={require('../../../assets/ic_up.png')} 
                                resizeMode='contain' 
                                style={{
                                    width:40,
                                    height:40,
                                    right:10,
                                    alignSelf:'center'
                                }}
                            ></Image>
                        }
                    </TouchableOpacity>
                </View>     
                <View style={{ height: this.state.expanded ? null : 0, overflow: 'hidden' }}>
                    <View style={{flexDirection:'column',marginLeft:10,marginTop:hp('3%')}}>
                        <CustomText style={{fontSize:hp('2.5%')}}>
                             Name
                        </CustomText>
                        <CustomTextInputInfo 
                            keyboardType='default' 
                            returnKeyType='next' 
                            value={value} 
                            onChange={onChangeValue} 
                            placeholder='Full Name' 
                            style={{
                                width:wp('75%'),
                                alignSelf:'center',
                                fontSize:hp('2.5%'),
                                marginTop:wp('2.9%'),
                                color:colors.GREY
                            }}
                        ></CustomTextInputInfo> 
                        <CustomText style={{fontSize:hp('2.5%'),marginTop:wp('5%')}}>
                            Address
                        </CustomText>
                        <CustomTextInputInfo 
                            keyboardType='email-address' 
                            returnKeyType='next'
                            placeholder='Address' 
                            style={{
                                width:wp('75%'),
                                alignSelf:'center',
                                fontSize:hp('2.5%'),
                                marginTop:wp('2.9%'),
                                color:colors.GREY
                            }}
                        ></CustomTextInputInfo> 
                        <View 
                            style={{
                                flex:1,
                                height:30,
                                flexDirection:'row',
                                marginTop:10,
                                justifyContent:'space-between'
                            }}
                        >
                            <Text style={{height:30,fontSize:hp('2.5%'),marginTop:wp('1%'),textAlign:'center'}}>{this.state.cityname}</Text>
                                <TouchableOpacity  onPress={this.changeLayoutDropisCity} style={{flexDirection:'row'}}>
                                    {this.state.isCity == false?    
                                        // this.setState({isListShow:false}):this.setState({isListShow:false})
                                        (
                                            <Image 
                                                source={require('../../../assets/ic_downn.png')} 
                                                resizeMode='contain' 
                                                style={{
                                                    width:40,
                                                    height:40,
                                                    justifyContent:'flex-end',
                                                    right:10
                                                }}
                                            ></Image>
                                        )
                                            
                                        : 
                                        (
                                            <Image 
                                                source={require('../../../assets/ic_up.png')} 
                                                resizeMode='contain' 
                                                style={{
                                                    width:40,
                                                    height:40,
                                                    justifyContent:'flex-end',
                                                    right:10
                                                }}
                                            ></Image>
                                        )
                                    }

                
                                </TouchableOpacity>
                            </View>
                            <View style={{ height: this.state.isCity ? null : 0, overflow: 'hidden' }}>
                                <View style={{flexDirection:'column'}}>
                                    <Overlay 
                                        isVisible={this.state.isCity}  
                                        onBackdropPress={() => this.setState({ isCity: false })}
                                        windowBackgroundColor="rgba(255, 255, 255, .5)"
                                        overlayBackgroundColor="red"
                                        width="auto"
                                        overlayStyle={{
                                            width:wp('70'),
                                            height:hp('20%'),
                                            top:hp('15%'),
                                            right:wp('6%')
                                        }}
                                    >
                                        <View style={styles.listontainer}>
                                            <FlatList
                                                data={[
                                                    {key: 'Indore'},
                                                    {key: 'Bhopal'},
                                                    {key: 'Dewas'},
                                                ]}
                                                renderItem={({item}) => 
                                                    <Text 
                                                        onPress={this.getListViewItem.bind(this, item)} 
                                                        style={styles.item}
                                                    >
                                                        {item.key}
                                                    </Text>
                                                }
                                            />
                                        </View>
                                    </Overlay>
                                </View>     
                            </View>
                            <View style={{ height:30,flexDirection:'row',marginTop:hp('3%'),justifyContent:'space-between'}}>
                                <Text style={{height:30,fontSize:hp('2.5%'),textAlign:'center'}}>{this.state.statname}</Text>
                                    <TouchableOpacity  onPress={this.changeLayoutDropisState}>
                                        {this.state.isState == false?    
                                            (
                                                <Image 
                                                    source={require('../../../assets/ic_downn.png')} 
                                                    resizeMode='contain' 
                                                    style={{
                                                        width:40,
                                                        height:40,
                                                        right:10
                                                    }}
                                                ></Image>
                                            )   
                                            : 
                                            (
                                                <Image 
                                                    source={require('../../../assets/ic_up.png')} 
                                                    resizeMode='contain' 
                                                    style={{
                                                        width:40,
                                                        height:40,
                                                        marginLeft:wp('54.5%')
                                                    }}
                                                ></Image>
                                            )
                                        }
                                    </TouchableOpacity>
                                </View>
                                <View style={{ height: this.state.isState ? null : 0, overflow: 'hidden' }}>
                                    <View style={{flexDirection:'column'}}>
             
                                        <Overlay 
                                            isVisible={this.state.isState}  
                                            onBackdropPress={() => this.setState({ isState: false })}
                                            windowBackgroundColor="rgba(255, 255, 255, .5)"
                                            overlayBackgroundColor="red"
                                            width="auto"
                                            overlayStyle={{
                                                width:wp('70'),
                                                height:hp('20%'),
                                                top:hp('15%'),
                                                right:wp('6%')
                                            }}
                                        >
                                            <View style={styles.listontainer}>
                                                <FlatList
                                                    data={[
                                                        {key: 'Mp'},
                                                        {key: 'Maharashtra'},
                                                    ]}
                                                    renderItem={({item}) => 
                                                        <Text  
                                                            onPress={this.getListViewItemState.bind(this,item)}  
                                                            style={styles.item}
                                                        >
                                                            {item.key}
                                                        </Text>
                                                    }
                                                />
                                            </View>
                                        </Overlay>
                                            {/* <CustomTextInputInfo placeholder='Address' style={{width:wp('75%'),alignSelf:'center',fontSize:wp('4.4%'),marginTop:wp('2.9%'),color:colors.GREY}}></CustomTextInputInfo>  */}

                                    </View>     
                                </View>
                                <View style={{ height:30,flexDirection:'row',marginTop:hp('3%'),justifyContent:'space-between'}}>
                                    <Text style={{height:30,fontSize:hp('2.5%'),textAlign:'center'}}>Add Pin Code</Text>
                                    <TouchableOpacity  onPress={this.changeLayoutDropisCountry}>
                                        {this.state.isCountry == false?    
                                            (
                                                <Image 
                                                    source={require('../../../assets/ic_downn.png')} 
                                                    resizeMode='contain' 
                                                    style={{width:40,height:40,right:10}}
                                                ></Image>
                                            )    
                                            : 
                                            (
                                                <Image 
                                                    source={require('../../../assets/ic_up.png')} 
                                                    resizeMode='contain' 
                                                    style={{width:40,height:40,right:10}}
                                                ></Image>
                                            )
                                        }
                                    </TouchableOpacity>
                                </View>
                                <View style={{ height: this.state.isCountry ? null : 0, overflow: 'hidden' }}>
                                    <View style={{flexDirection:'column'}}>
                                        <CustomTextInputInfo 
                                            placeholder='Country' 
                                            style={{
                                                width:wp('75%'),
                                                fontSize:hp('2.5%'),
                                                color:colors.GREY
                                            }}
                                        ></CustomTextInputInfo> 
                                    </View>     
                                </View>
                                <View style={{ height:30,flexDirection:'row',marginTop:hp('3%'),justifyContent:'space-between'}}>
                                    <Text style={{height:30,fontSize:hp('2.5%'),textAlign:'center'}}>Add Pin Code</Text>
                                    <TouchableOpacity  onPress={this.changeLayoutDropisPinCode}>
                                        {this.state.isPinCode == false?    
                                            (
                                                <Image 
                                                    source={require('../../../assets/ic_downn.png')} 
                                                    resizeMode='contain' 
                                                    style={{width:40,height:40,right:10}}
                                                ></Image>
                                            )    
                                            : 
                                            (
                                                <Image 
                                                    source={require('../../../assets/ic_up.png')} 
                                                    resizeMode='contain' 
                                                    style={{width:40,height:40,right:10}}
                                                ></Image>
                                            )
                                        }
                                    </TouchableOpacity>
                                </View>
                                <View style={{ height: this.state.isPinCode ? null : 0, overflow: 'hidden' }}>
                                    <View style={{flexDirection:'column'}}>
                                        <CustomTextInputInfo 
                                            placeholder='Pentode/Zip Code' 
                                            style={{
                                                width:wp('75%'),
                                                fontSize:hp('2.5%'),
                                                color:colors.GREY
                                            }}
                                        ></CustomTextInputInfo> 
                                    </View>
                                </View>
                            </View>
                        </View>
                    </View>
        );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 10,
    justifyContent: 'center',
    paddingTop: (Platform.OS === 'ios') ? 20 : 0
  },

  text: {
    fontSize: 17,
    color: 'black',
    padding: 10
  },

  btnText: {
    textAlign: 'center',
    color: 'white',
    fontSize: 20
  },

  btnTextHolder: {
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.5)'
  },

  Btn: {
    padding: 10,
    backgroundColor: 'rgba(0,0,0,0.5)'
  },listontainer: {
    flex: 1,
    paddingTop: 2,
  
   },
   item: {
     flex:1,
      
     fontSize: 18,
     height: 44,
   },
});