import React, { Component } from 'react';
import { Text, View, StyleSheet, TouchableOpacity, StatusBar, ScrollView, Image,CheckBox ,Alert} from 'react-native';

import colors from '../../../utility/color';
import CustomText from '../../../components/CustomText';
import { GenericStyles } from '../../otp/GenericStyles';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import SenderInformation from '../addOrder/SenderInformation';
import ReceiverInfomation from '../addOrder/ReceiverInformation';
import ParcelrInformation from '../addOrder/ParcelInformation';
import PickupTime from '../addOrder/PickupTime';
import { FullButtonComponent } from '../../../components/customview';


 

class AddOrderScreens extends Component{
 
  state = {
    value: ''
  }
   onChangeValueHandler (val) {
    // alert('Alert with one button');

  }
  
    render(){
        return(
            <View style={styles.container}>
                <StatusBar backgroundColor={colors.FONT_COLOR} />
                <ScrollView>
                    <View style={styles.headerView}>
                        <CustomText  style={styles.headerText}>Add Order</CustomText>
                    </View>
                    <View style={{marginBottom:80}}>
                        <SenderInformation></SenderInformation>
                        <ReceiverInfomation></ReceiverInfomation>
                    
                        <View style={{
                            flexDirection:'row',marginLeft:10,marginTop:hp('5%')
                            }}
                        >
                            <Image source={require('../../../assets/ic_deliver.png')} resizeMode='contain' style={{width:40,height:40,marginLeft:20}}></Image>
                            <CustomText style={{fontSize:hp('3%'),marginLeft:25,textAlign:'center',alignSelf:'center'}}>Delivery Service</CustomText>
                        </View>
                        <View style={{
                            flexDirection:'row',marginLeft:10,
                            marginTop:hp('5%')}}
                        >
                            <Image source={require('../../../assets/ic_price.png')} resizeMode='contain' style={{width:40,height:40,marginLeft:20}}></Image>
                            <CustomText style={{fontSize:hp('3%'),alignSelf:'center',marginLeft:25,alignSelf:'center',textAlign:'center'}}>Approximate Price</CustomText>
                        </View>
                
                        <ParcelrInformation></ParcelrInformation>

                        <PickupTime></PickupTime>
                        <View style={{flexDirection:'row'}}>
                            <CheckBox
                                style={{padding: 10,marginLeft:15,marginTop:20}}
                            /> 

                            <CustomText style={{marginLeft:10,marginTop:25,fontSize:15}}>Terms and Conditions</CustomText>
                        </View>
                        <View style={{marginRight:40,marginLeft:20}}>
                            <FullButtonComponent
                                type={'fill'}
                                text={'Submit'}
                                textStyle={styles.submitButtonText}
                                buttonStyle={GenericStyles.mt24}
                            /> 
                        </View> 
                    </View>
                </ScrollView>
            </View>
        )
    }
}

const styles = StyleSheet.create({
  container:{
    flex:1
  },headerView:{
    flexDirection:'row',
    alignSelf:'center'
  },headerText:{
    color:colors.BLACK,
    textAlign:'center',
    fontSize:wp('6%'),
    margin:35,
    fontWeight:'900'
   },contentView:{
     height:60,
     flexDirection:'row',
      
     marginTop:25
   },contentViewText:{
     flex:1,
 
     fontSize:20,
     marginLeft:'6%',
     color:colors.DARK_GREY,
   }  ,submitButtonText: {
     color: colors.WHITE,
     fontSize:17,
   },checkboxContainer: {
   flexDirection: "row",
   marginBottom: 20,
 },
 checkbox: {
   alignSelf: "center",
 },
 label: {
   margin: 8,
 },

});

export default AddOrderScreens; 