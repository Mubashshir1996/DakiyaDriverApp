import React, { Component } from 'react';
import { 
    Text, 
    View,
    Image, 
    StyleSheet, 
    LayoutAnimation, 
    Platform, 
    UIManager, 
    TouchableOpacity,
    ScrollView, 
    StatusBar, 
    TextInput 
} from 'react-native';
import colors from '../../../../utilty/color';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import CustomTextInputInfo from '../../../commonview/CustomTextInputInfo';
import CustomText from '../../../commonview/CustomText';
import { ListItem, Card, Overlay } from 'react-native-elements';
import { FlatList } from 'react-native-gesture-handler';






export default class ParcelrInformation extends Component {
    constructor() {
        super();

        this.state = { expanded: false,isDropDown:false,isCity:false ,isState:false,isCountry:false,isPinCode:false}

        if (Platform.OS === 'android') {
            UIManager.setLayoutAnimationEnabledExperimental(true);
        }
    }

    changeLayout = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ expanded: !this.state.expanded });
    }
    changeLayoutDropisCity = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        // this.setState({ isDropDown: !this.state.isDropDown });
        this.setState({ isCity: !this.state.isCity });
    }
    changeLayoutDropisState = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ isState: !this.state.isState });
    }
    changeLayoutDropisCountry = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ isCountry: !this.state.isCountry });
    }
    changeLayoutDropisPinCode= () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ isPinCode: !this.state.isPinCode });
    }
 

    render() {
        const options = [
        {
            label: 'News'
        },
        {
            label: 'Design'
        },
        {
            label: 'Sales'
        },
        {
            label: 'Marketing'
        },
        {
            label: 'Customer Success'
        }
        ];
        return (
            <View style={styles.container}>
                {/* <View  style={{justifyContent:'space-between',flex:1,flexDirection:'column'}} > */}
        
                <View 
                    style={{
                        aspectRatio:5.1,
                        flex:1,
                        height:wp('18%'),
                        borderWidth:1.2,
                        borderColor:colors.WHITE_GREY,
                        alignSelf:'center',
                        flexDirection:'row',
                        justifyContent:'space-between',
                        marginTop:30
                    }}
                >
                    <Image source={require('../../../assets/ic_parcel_ifno.png')} resizeMode='contain' style={{flexDirection:'row',marginLeft:10,width:40,height:30,alignSelf:'center'}}></Image>
                    <Text 
                        style={{
                            flexDirection:'row',
                            right:9,fontSize:hp('3%'),
                            alignSelf:'center'
                        }}
                    >
                        Parcelr Information
                    </Text>
                    <TouchableOpacity  onPress={this.changeLayout} style={{alignSelf:'center'}}>
                        {this.state.expanded == false?      
                        <Image source={require('../../../assets/ic_downn.png')} resizeMode='contain' style={{flexDirection:'row',width:40,height:40,right:10,alignSelf:'center'}}></Image>
                        :<Image source={require('../../../assets/ic_up.png')} resizeMode='contain' style={{width:40,height:40,right:10,alignSelf:'center'}}></Image>}
    
                    </TouchableOpacity>
                </View>     
                <View 
                    style={{ 
                        height: this.state.expanded ? null : 0, overflow: 'hidden' 
                    }}
                >
                    <View style={{flexDirection:'column',marginLeft:10,marginTop:10}}>
                        <CustomText style={{fontSize:hp('2.5 %')}}>
                            Add Name
                        </CustomText>
                        <CustomTextInputInfo placeholder='Item Name' 
                            style={{
                                width:wp('75%'),
                                alignSelf:'center',
                                fontSize:hp('2.5 %'),
                                marginTop:wp('2.9%'),
                                color:colors.GREY
                            }}
                        ></CustomTextInputInfo> 


                        <View 
                            style={{ 
                                height:30,
                                flexDirection:'row',
                                marginTop:10,
                                justifyContent:'space-between'
                            }}
                        >
                            <Text style={{height:30,fontSize:hp('2.5 %'),marginTop:wp('1%'),textAlign:'center'}}>Multiple such items can be added</Text>
                            <TouchableOpacity  onPress={this.changeLayoutDropisCity}>
                                {this.state.isCity == false?    
                                    (
                                        <Image source={require('../../../assets/ic_downn.png')} resizeMode='contain' style={{width:40,height:40,right:10}}></Image>
                                    )
                                        
                                    : 
                                    (
                                        <Image source={require('../../../assets/ic_up.png')} resizeMode='contain' style={{width:40,height:40,right:10}}></Image>
                                    )
                                }

                            </TouchableOpacity>
                        </View>

                        <View style={{ height: this.state.isCity ? null : 0, overflow: 'hidden' }}>
                            <View style={{flexDirection:'column'}}>
                                <Overlay 
                                    isVisible={this.state.isCity}  
                                    onBackdropPress={() => this.setState({ isCity: false })}
                                    windowBackgroundColor="rgba(255, 255, 255, .5)"
                                    overlayBackgroundColor="red"
                                    width="auto"
                                    overlayStyle={{width:wp('70'),height:hp('20%'),top:hp('15%'),right:wp('6%')}}
                                >

                                    <View style={styles.listontainer}>
                                        <FlatList
                                            data={[
                                                {key: 'Indore'},
                                                {key: 'Bhopal'},
                                                {key: 'Dewas'},
                                            
                                            ]}
                                            renderItem={({item}) => 
                                                <Text style={styles.item}>{item.key}</Text>
                                            }
                                        />
                                    </View>
                                </Overlay>

                            </View>     
                        </View>
                        <View style={{ height:30,flexDirection:'row',marginTop:hp('3%'),justifyContent:'space-between'}}>
                            <Text style={{height:30,fontSize:hp('2.5%'),textAlign:'center'}}>00 KG</Text>
                            <TouchableOpacity  onPress={this.changeLayoutDropisCountry}>
                                {this.state.isCountry == false?    
                                    (
                                        <Image source={require('../../../assets/ic_downn.png')} resizeMode='contain' style={{width:40,height:40,right:10}}></Image>
                                    )
                                        
                                    : 
                                    (
                                        <Image source={require('../../../assets/ic_up.png')} resizeMode='contain' style={{width:40,height:40,right:10}}></Image>
                                    )
                                }
                            </TouchableOpacity>
                        </View>
                        <View style={{ height: this.state.isCountry ? null : 0, overflow: 'hidden' }}>
                            <View style={{flexDirection:'column'}}>
                                <CustomTextInputInfo placeholder='Parcel wait' 
                                    style={{
                                        marginTop:10,
                                        width:wp('75%'),
                                        fontSize:hp('2.5 %'),
                                        color:colors.GREY
                                    }}
                                ></CustomTextInputInfo> 
                            </View>
    
                        </View>     
                    </View>
                    <View style={{flexDirection:'column',marginLeft:10}}>
                        <CustomText style={{fontSize:hp('2.5%'),marginTop:wp('3%')}}>
                            Add Name
                        </CustomText>

                        <Image source={require('../../../assets/ic_upload.png')} resizeMode='contain' style={{marginTop:'1.5%',width:wp('13%'),height:hp('13%')}}></Image>
                    </View>

                </View>
            </View>
        
        
        
        );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 10,
    justifyContent: 'center',
    paddingTop: (Platform.OS === 'ios') ? 20 : 0
  },

  text: {
    fontSize: 17,
    color: 'black',
    padding: 10
  },

  btnText: {
    textAlign: 'center',
    color: 'white',
    fontSize: 20
  },

  btnTextHolder: {
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.5)'
  },

  Btn: {
    padding: 10,
    backgroundColor: 'rgba(0,0,0,0.5)'
  },listontainer: {
    flex: 1,
    paddingTop: 2,
  
   },
   item: {
     flex:1,
      
     fontSize: 18,
     height: 44,
   },
});