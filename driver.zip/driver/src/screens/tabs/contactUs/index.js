import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList,
    KeyboardAvoidingView
} from 'react-native';
import CustomText from '../../../components/CustomText';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../utility/color';
import InputBoxImage from '../../../components/inputBoxImage';
import { FullButtonComponent } from '../../../components/customview';
import { GenericStyles } from '../../otp/GenericStyles';




function ContactUsScreen(){

    return(
        <KeyboardAvoidingView style={{flex:1}}>
            <StatusBar backgroundColor={colors.FONT_COLOR} />
            <ScrollView style={{flexDirection:'column'}}>
                <View style={styles.container}>
                    <View style={styles.headerView}>
                        <CustomText style={styles.headerText}>Contact Us</CustomText>
                    </View>
                    <View style={{flexDirection:'row',justifyContent:'center'}}>
                        <Image 
                            source={require('../../../assets/screen_logo.png')} 
                            resizeMode='contain' 
                            style={{width:wp('80%'),height:hp('35%'),padding:0}} 
                        ></Image>
                    </View>
                    <View style={{flexDirection:'row',marginRight:wp('4%')}}>
                        <InputBoxImage 
                            levelfontSize={hp('2.1%')} 
                            inputFontSize={hp('2%')} 
                            keyboardType={'default'} 
                            returnKeyType={'next'} 
                            leftMar={wp('4%')} 
                            type={0} 
                            width={wp('8%')} 
                            height={wp('8%')}  
                            name='Name' 
                            placename='Enter Name' 
                            path={require('../../..//assets/ic_name.png')}
                        />
                    </View>
                    <View style={{flexDirection:'row',marginTop:wp('5%'),marginRight:wp('4%')}}>
                        <InputBoxImage 
                            levelfontSize={hp('2.1%')} 
                            inputFontSize={hp('2%')} 
                            keyboardType={'email-address'} 
                            returnKeyType={'next'} 
                            leftMar={wp('4%')} 
                            type={0} 
                            width={wp('8%')} 
                            height={wp('8%')}  
                            name='Email' 
                            placename='Enter Email' 
                            path={require('../../..//assets/ic_email.png')}
                        />
                    </View>
                    <View style={{flexDirection:'row',marginTop:wp('5%'),marginRight:wp('4%')}}>
                        <InputBoxImage 
                            levelfontSize={hp('2.1%')} 
                            inputFontSize={hp('2%')} 
                            keyboardType={'default'} 
                            returnKeyType={'next'}  
                            leftMar={wp('4%')} 
                            type={0} 
                            width={wp('8%')} 
                            height={wp('8%')}  
                            name='Description' 
                            placename='Enter Description' 
                            path={require('../../..//assets/ic_des.png')}
                        />
                    </View>
                    <View style={{marginRight:40,marginLeft:20,paddingBottom:wp('30%'),marginTop:30}}>
                        <FullButtonComponent
                            type={'fill'}
                            text={'Submit'}
                            textStyle={styles.submitButtonText}
                            buttonStyle={GenericStyles.mt24}
                        />
                    </View>
                </View>  
            </ScrollView>
        </KeyboardAvoidingView>
    )
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column'
    },
    headerView:{
        flexDirection:'row',
        justifyContent:'center',
        marginTop:hp('5%')
    },
    headerText:{
        alignSelf:'center',
        fontSize:hp('3%'),
        color:colors.FONT_COLOR,
        fontFamily:'NunitoSans-Bold'
    },
    contentView:{
        flexDirection:'column',
        marginTop:hp('8%'),
        marginLeft:wp('10%')
    },
    contentText:{
     fontSize:hp('2%'),
     color:colors.BLACK,
     fontFamily:'NunitoSans-Regular'
    },
    secontentView:{
     flexDirection:'column',
     marginTop:hp('8%'),
     marginLeft:wp('10%')
    },
    submitButtonText: {
      color: colors.WHITE,
      fontSize:hp('2.5%'),
      fontFamily:'NunitoSans-Regluar'
    },

});

export default ContactUsScreen;



