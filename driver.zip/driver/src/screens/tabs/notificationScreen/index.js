import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList,
    KeyboardAvoidingView,
    TouchableOpacity
} from 'react-native';
import CustomText from '../../../components/CustomText';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../../utility/color';

function NotificationScreen({navigation}){
    return(
        <KeyboardAvoidingView style={{flex:1}}>
            <StatusBar backgroundColor={colors.FONT_COLOR} /> 
            <View style={styles.container}>
                <View style={styles.headerView}>
                    <TouchableOpacity onPress={() => navigation.goBack(null)}>
                        <Image 
                            source={require('../../../assets/ic_left_arrow.png')} 
                            resizeMode='contain' 
                            style={{width:wp('4.5%'),height:hp('5%'),marginLeft:wp('5%')}}
                        />
                    </TouchableOpacity>
                    <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignSelf:'center'}}>
                        <CustomText style={styles.headerText}>Notification</CustomText>
                    </View>
                </View>
                <View style={styles.contentView}>
                    <View style={{flexDirection:'row',justifyContent:'space-between',flex:1}}>
                        <View style={{width:wp('9%'),height:hp('9%'),flexDirection:'column',alignSelf:'center',justifyContent:'center'}}>
                            <Image 
                                source={require('../../../assets/ic_bell_y.png')} 
                                resizeMode='contain' 
                                style={{alignSelf:'center',width:wp('7%'),height:hp('7%')}}
                            />
                        </View> 
                        <View style={{flexDirection:'column',alignSelf:'center',width:wp('50%'),height:'auto',right:wp('5%')}}>
                            <CustomText style={{color:colors.BLACK,fontFamily:'NunitoSans-Regular',fontSize:hp('1.9%')}}>Lorem Ipsum is simply dummy text of the printing</CustomText>
                            <CustomText style={{color:colors.GREY,fontSize:hp('1.7%'),fontFamily:'NunitoSans-Regular'}}>Name Sender</CustomText>  
                        </View>
                        <View style={{right:wp('3%'),flexDirection:'column',justifyContent:'flex-end'}}>
                            <CustomText style={{color:colors.GREY,fontSize:hp('1.7%'),fontFamily:'NunitoSans-Regular'}}>12:01PM</CustomText> 
                        </View>
                    </View>
                    <View style={{flexDirection:'column',marginLeft:wp('4%'),marginTop:hp('9%')}}>
                        <CustomText style={{marginRight:hp('20%'),color:colors.BLACK,fontSize:hp('2.1%'),fontFamily:'NunitoSans-Bold'}}>Yesterday</CustomText> 
                    </View>
                    <View style={{marginTop:hp('7%'),flexDirection:'row',justifyContent:'space-between',flex:1}}>
                        <View style={{width:wp('9%'),height:hp('9%'),flexDirection:'column',alignSelf:'center',justifyContent:'center'}}>
                            <Image 
                                source={require('../../../assets/ic_package.png')} 
                                resizeMode='contain' 
                                style={{alignSelf:'center',width:wp('7%'),height:hp('7%')}}
                            />
                        </View> 
                        <View style={{flexDirection:'column',alignSelf:'center',width:wp('50%'),height:'auto',right:wp('5%')}}>
                            <CustomText style={{color:colors.BLACK,fontSize:hp('1.9%'),fontFamily:'NunitoSans-Regular'}}>
                                Lorem Ipsum is simply dummy text of the printing
                            </CustomText>
                            <CustomText style={{color:colors.GREY,fontSize:hp('1.7%'),fontFamily:'NunitoSans-Regular'}}>
                                Name Sender
                            </CustomText>  
                        </View>
                        <View style={{right:wp('3%'),flexDirection:'column',justifyContent:'flex-end'}}>
                            <CustomText style={{color:colors.GREY,fontSize:hp('1.7%'),fontFamily:'NunitoSans-Regular'}}>12:01PM</CustomText> 
                        </View>
                    </View>
                </View>
            </View>
        </KeyboardAvoidingView>
    )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column'
    },
    headerView:{
        flexDirection:'row',
        marginTop:hp('5%')
    },
    headerText:{
        justifyContent:'center',
        alignSelf:'center',
        fontSize:hp('3%'),
        color:colors.FONT_COLOR,
        fontFamily:'NunitoSans-Bold'
    },
    contentView:{
        flexDirection:'column',
        marginTop:hp('10%'),
        marginLeft:wp('6.5%')    
    },
    contentText:{
        fontSize:hp('1.9%'),
        color:colors.BLACK,
        fontFamily:'NunitoSans-Bold'
    }
})

export default NotificationScreen;
  