import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList,
    KeyboardAvoidingView,
    TouchableOpacity
} from 'react-native';
import { Icon, Avatar, Card } from 'react-native-elements'


import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import CustomText from '../../components/CustomText';
import colors from '../../utility/color';
import MapView, { PROVIDER_GOOGLE, Marker } from 'react-native-maps';
import { CustomTextInput, FullButtonComponent } from '../../components/customview';
import { GenericStyles } from '../otp/GenericStyles';


function SaveLocationScreen({navigation}){

    function getInitialState() {
        return {
            coordinate: {
                latitude: 22.7196,
                longitude: 75.8577
            }
        };
    }

    function onRegionChange(region) {
        this.state.region.setValue(region);
    }

    return(
        <KeyboardAvoidingView style={{flex:1}}>
            <StatusBar backgroundColor={colors.FONT_COLOR} />
            <View style={styles.container}>
                <View style={styles.headerView}>
                    <TouchableOpacity onPress={() => navigation.goBack(null)}>
                        <Image 
                            source={require('../../../assets/images/ic_left_arrow.png')} 
                            resizeMode='contain' 
                            style={{width:wp('4.5%'),height:hp('5%'),marginLeft:wp('5%')}}
                        />
                    </TouchableOpacity>
                    <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignSelf:'center',marginRight:wp('11%')}}>
                        <CustomText style={styles.headerText}>Tracking</CustomText>
                    </View>
                </View>
                <ScrollView style={{flex:1,flexDirection:'column'}} >
                    <View  style={{flex:1,flexDirection:'column'}}>
                        <View style={{flexDirection:'row',position:'relative'}}>
                            <MapView 
                                style={{width:wp('100%'),height:hp('100%'),marginTop:wp('10%')}}
                                provider={PROVIDER_GOOGLE}         
                                initialRegion={{
                                    latitude: 22.7196,
                                    longitude: 75.8577,
                                    latitudeDelta: 0.0922,
                                    longitudeDelta: 0.0421
                                }}
                                loadingIndicatorColor={colors.FONT_COLOR}
                                showsIndoors

                            >
                                <Marker.Animated
                                    coordinate={getInitialState().coordinate}
                                />
                            </MapView>        
                        </View>
                        <View style={{flex:1,flexDirection:'column',position:'absolute'}}>
                            <View style={{flexDirection:'column'}}>
                                <View style={{flexDirection:'row',justifyContent:'center',marginTop:hp('10%')}}>
                                    <View style={{left:wp('40%'),width:wp('25%'),height:hp('6%'),justifyContent:'center',backgroundColor:colors.FONT_COLOR,borderRadius:7}}>
                                        <CustomText 
                                            style={{ 
                                                fontFamily:'NunitoSans-Bold',
                                                alignSelf:'center',
                                                left:wp('1%'),
                                                color:colors.WHITE,
                                                fontSize:hp('1.9%'),
                                                justifyContent:'center'
                                            }}
                                        >
                                            01:00 PM
                                        </CustomText>
                                    </View>
                                </View>
                                <View style={{flex:0.5,left:wp('80%'),height:hp('6%'),justifyContent:'center',top:hp('25%')}}>
                                    <Image 
                                        source={require('../../../assets/images/ic_compass.png')} 
                                        resizeMode='contain' 
                                        style={{width:wp('11%'),height:hp('11%')}}
                                    ></Image>
                                </View>
                                <View style={{flex:1,left:20,flexDirection:'row',backgroundColor:colors.FONT_COLOR,height:hp('20%'),alignSelf:'center',width:wp('90%'),justifyContent:'space-between',top:hp('30%'),borderRadius:7}}>
                                    <View style={{flex:0.4}}>
                                        <Image 
                                            source={require('../../../assets/images/ic_avtarr.png')} 
                                            resizeMode='contain' 
                                            style={{borderTopLeftRadius:7,borderBottomLeftRadius:7,width:wp('40%'),right:wp('1.18%'),height:hp('20%')}}
                                        ></Image>
                                    </View> 
                                    <View style={{flex:0.59,flexDirection:'column',marginTop:10}}>
                                        <View style={{flexDirection:'row',justifyContent:'flex-start',alignSelf:'flex-start',paddingLeft:wp('3%'),paddingTop:hp('1.5%')}}>
                                            <CustomText style={{fontSize:hp('1.9%'),color:colors.WHITE,fontFamily:'NunitoSans-Regular',alignSelf:'flex-start',justifyContent:'flex-start'}}>
                                                Name
                                            </CustomText>
                                            <CustomText style={{fontSize:hp('1.9%'),fontFamily:'NunitoSans-Regular',color:colors.WHITE}}>
                                                :  Lorem Ipsum
                                            </CustomText>      
                                        </View> 
                                        <View style={{flexDirection:'row',justifyContent:'flex-start',alignSelf:'flex-start',paddingLeft:wp('3%'),paddingTop:wp('1%')}}>
                                            <CustomText style={{fontSize:hp('1.9%'),color:colors.WHITE,fontFamily:'NunitoSans-Regular',alignSelf:'flex-start',justifyContent:'flex-start'}}>
                                                Adddress
                                            </CustomText>
                                            <CustomText style={{fontSize:hp('1.9%'),fontFamily:'NunitoSans-Regular',color:colors.WHITE}}>
                                                :  Lorem Ipsum
                                            </CustomText>      
                                        </View> 
                                        <View style={{flexDirection:'row',justifyContent:'flex-start',alignSelf:'flex-start',paddingLeft:wp('3%'),paddingTop:wp('1%')}}>
                                            <CustomText style={{fontSize:hp('1.9%'),color:colors.WHITE,fontFamily:'NunitoSans-Regular',alignSelf:'flex-start',justifyContent:'flex-start'}}>
                                                5.20 KM
                                            </CustomText>
                
                                        </View> 
                                        <View style={{flexDirection:'row',justifyContent:'flex-start',alignSelf:'flex-end',paddingRight:wp('3%'),bottom:hp('2.5%'),paddingLeft:wp('3%'),paddingTop:wp('1%')}}>
                                            <Image 
                                                source={require('../../../assets/images/ic_call.png')} 
                                                resizeMode='contain' 
                                                style={{width:wp('10%'),height:hp('10%')}}
                                            ></Image>
                
                                        </View> 
                                    </View> 
                                </View>
                            </View>        
                        </View>
                    </View>
                </ScrollView>
            </View>
        </KeyboardAvoidingView>   
    )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column'
    },
    headerView:{
        flexDirection:'row',
        marginTop:hp('5%')
    },
    headerText:{
        marginLeft:wp('6%'),
        fontSize:hp('3%'),
        color:colors.FONT_COLOR,
        fontWeight:'bold'
    },
    contentView:{
        flexDirection:'row',
        marginTop:hp('4%'),
        alignSelf:'center'
    },
    contentText:{
        fontSize:wp('5%'),
        color:colors.BLACK
    },
    addressHeader:{
        marginLeft:wp('7%'),
        fontSize:wp('4%'),
        fontWeight:'normal',
        color:colors.BLACK
    },
    submitButtonText: {
        color: colors.WHITE,
        fontSize:17
    },
  
})

export default SaveLocationScreen;