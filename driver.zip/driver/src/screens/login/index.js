import React,{ useEffect, useStat} from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image
  } from 'react-native';
import InputBox from '../../components/InputBox';
import ButtonBox from '../../components/ButtonBox';
import TextBox from '../../components/TextBox';
import CommonTextBox from '../../components/CommonTextBox';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { CustomButton, FullButtonComponent } from '../../components/customview';
import { GenericStyles } from '../otp/GenericStyles';
import colors from '../../utility/color';



export default function LoginPage() {
    var navigation = this.props.navigation
return(
        <ScrollView>
            <View style={styles.container}>
                <StatusBar backgroundColor={colors.FONT_COLOR} />

                <View style={styles.imageLogoCon}>
                    <Image 
                        source={require('../../../assets/images/screen_logo.png')} 
                        resizeMode='center'
                    ></Image>

                </View>
                <View style={styles.textBox}>
                    <TextBox frist_split_syntax={"Enter your"} type={0} second_split_syntax={" Mobile Number"} third_split_syntax={" we'll send\n you an"} fourth_split_syntax={"OTP to Verify"}></TextBox>
                </View>
                <View style={styles.inputBox}>
                    <InputBox></InputBox> 
                </View>
                <View style={styles.buttonBox}>
                    <FullButtonComponent
                        type={'fill'}
                        text={'Submit'}
                        textStyle={styles.submitButtonText}
                        onPress={() =>  navigation.navigate("OtpVerification")}
                    /> 
                </View>
     
                <View style={styles.commonTextBox}>
                    <CommonTextBox value={"Or create account using"} colorstate={'#414141'} isBold={false} size={15}></CommonTextBox>
                </View>
                <View style={styles.commonSubTextBox}  >
                    <CommonTextBox value={"Social Media"} colorstate={'#414141'} isBold ={true} size={18}></CommonTextBox>
                </View>
                <View style={styles.socialbtn}  >
                    <Image 
                        source={require('../../../assets/images/ic_facebook.png')} 
                        resizeMode='center' 
                        style={{flexDirection:'column',width:50,height:50}}
                    ></Image> 
                    <Image 
                        source={require('../../../assets/images/ic_gplus.png')} 
                        resizeMode='center' 
                        style={{flexDirection:'column',width:50,height:50,marginLeft:35}}
                    ></Image> 

                </View>
     
            </View>
        </ScrollView>
    );
}


const styles =StyleSheet.create({
 container:{
        flex:1
    },
 textBox:{
        flexDirection:"row",
        alignItems:'center', 
        marginTop:100
    },
 imageLogoCon:{
        flexDirection:"row",
        alignItems:'center',
        height:60,
        justifyContent:'center',
        marginTop:100
    },
 inputBox:{
        flexDirection:'row',
        justifyContent:'center',
        marginTop:20,
    },
 buttonBox:{
        flexDirection:'row',
        justifyContent:'center',
        marginTop:50,
        marginLeft:30,
        marginRight:30
    },
 commonTextBox:{
        flexDirection:'row',
        justifyContent:'center',
        marginTop:50,
    },
 commonSubTextBox:{
        flexDirection:'row',
        justifyContent:'center',
        marginTop:10,
    },
 socialbtn:{
        justifyContent:'center',
        marginTop:40,
        flexDirection:'row',
    }, 
 submitButtonText: {
        color: colors.WHITE,
        fontSize:17,
    },

})
