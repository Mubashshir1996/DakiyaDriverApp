import axios from "axios";
import { api_key } from "../config/apiKey";
import { AsyncStorage } from "react-native";

export const tokenApi = async () => {
  const token = await AsyncStorage.getItem("userToken");
  return axios.create({
    baseURL: "",
    headers: {
      "Content-Type": "application/json",
      "api-key": api_key,
      token: token,
    },
  });
};