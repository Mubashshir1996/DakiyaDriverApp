
import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator} from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { Image ,Text } from 'react-native'
import HomeScreen from '../tabs/home/HomeScreen';
import colors from '../../../utilty/color';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import AboutusScreen from '../tabs/aboutsus/Aboutus';
import ContactUsScreen from '../tabs/contactus/Contactus';
import AnimatedTabBar, { TabsConfigsType } from '../../commonview/curvedbottomNav'
import JobHistoryScreen from '../tabs/orderhistory/JobHistoryScreen';
import AcceptedOrder from '../tabs/acceptorder/AcceptedOrder';


const TabsConfigsType =()=> {
    Home: {
        icon: ({ progress }) =>  
        <Image 
            source={require('../../../assets/images/ic_home_white.png')} 
            resizeMode='contain' 
            style={{width:wp('6%'),height:hp('6%')}}
        />
    },
    JobHistory: {
        icon: ({ progress }) =>  
        <Image 
            source={require('../../../assets/images/ic_jobh_white.png')} 
            resizeMode='contain' 
            style={{width:wp('6%'),height:hp('6%')}}
        />
    },
    Buket: {
        icon: ({ progress }) =>  
        <Image 
            source={require('../../../assets/images/ic_boxx_white.png')} 
            resizeMode='contain' 
            style={{width:wp('6%'),height:hp('6%')}}
        />
    },
    ContactUS: {
        icon: ({ progress }) =>  
        <Image 
            source={require('../../../assets/images/ic_contact_white.png')} 
            resizeMode='contain' 
            style={{width:wp('6%'),height:hp('6%')}}
        />
    },
    AboutUS: {
        icon: ({ progress }) =>  
        <Image 
            source={require('../../../assets/images/ic_user_whiteeee.png')} 
            resizeMode='contain' 
            style={{width:wp('6%'),height:hp('6%')}}
        />
    },
}
const Tab = createBottomTabNavigator()

function MyTabs() {
    return (
        <Tab.Navigator
            tabBar={props => (
                <AnimatedTabBar 
                    barColor={colors.FONT_COLOR} 
                    tabs={tabs} 
                    dotColor={colors.FONT_COLOR}  
                    {...props}  dotSize={80}
                />
            )}
        >
            <Tab.Screen
                name="Home"
                component={HomeScreen}
            />
            <Tab.Screen
                name="JobHistory"
                component={JobHistoryScreen}
            />
            <Tab.Screen
                name="Buket"
                component={AcceptedOrder}     
            />        
            <Tab.Screen
                name="ContactUS"
                component={ContactUsScreen}           
            />
            <Tab.Screen
                name="AboutUS"
                component={AboutusScreen}      
            /> 
        </Tab.Navigator>
    );
}

export default MyTabs;
