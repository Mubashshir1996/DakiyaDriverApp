import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator} from '@react-navigation/stack';
import LoginPage from '../../screens/login';
import OtpVerification from '../../screens/otp/OtpVerification';
import HomeScreen from '../../screens/tabs/homeScreen';
import MyTabs from '../myTabs';
import NotificationScreen from '../../screens/tabs/notificationScreen';
import ProfileScreen from '../../screens/tabs/account/ProfileScreen';
import SearchYourLocation from '../../screens/searchYourLocation';
import SaveLocationScreen from '../../screens/saveLocationScreen';
import ContactUsScreen from '../../screens/tabs/contactUs';
import AboutusScreen from '../../screens/tabs/aboutUs';
import WalletScreen from '../../screens/tabs/account/WalletScreen';
import JobHistoryScreen from '../../screens/tabs/jobHistoryScreen';
import AcceptedOrder from '../../screens/tabs/AcceptedOrder';
import OrderSlipScreen from '../../screens/orderslip/index';
import { FilterScreen } from '../../screens/tabs/filter';


export const loginPage=()=>{
    const LognStack = createStackNavigator();

    return(
        <LognStack.Navigator 
            screenOptions={{headerShown: false}}
        >
            <LognStack.Screen  name="LoginPage" component={LoginPage} />
            <LognStack.Screen  name="OtpVerification" component={OtpVerification} />  
            <LognStack.Screen  name="MyTabs" component={MyTabs} />
            <LognStack.Screen  name="NotificationScreen" component={NotificationScreen}/>
            <LognStack.Screen  name="FilterScreen" component={FilterScreen}/> 
            <LognStack.Screen  name="ProfileScreen" component={ProfileScreen}/>
            <LognStack.Screen  name="WalletScreen" component={WalletScreen}/>
            <LognStack.Screen  name="SearchYourLocation" component={SearchYourLocation}/>
            <LognStack.Screen  name="SaveLocationScreen" component={SaveLocationScreen}/> 
            <LognStack.Screen  name="OrderSlipScreen" component={OrderSlipScreen}/>    
        </LognStack.Navigator>
    );
}
// export default loginPage


export const Route =() => {
    const Stack = createStackNavigator();

    return (
        <NavigationContainer>
            <Stack.Navigator  
                screenOptions={{headerShown: false}} initialRouteName="LoginPage"
            >
                <Stack.Screen  name="LoginPage" component={loginPage}/>
            </Stack.Navigator>
        </NavigationContainer>
    );
}

// export default Route;


