import React,{Component} from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    TextInput,
    StatusBar,
    TouchableOpacity,
} from 'react-native';

const TextBox = ({frist_split_syntax,second_split_syntax,third_split_syntax,fourth_split_syntax,type})  => {
    return(
        <View style={{flex:1,flexDirection:'row',justifyContent:'center'}}>
            <View style={{alignContent:'center'}}>
                <Text style={{color:'#958C63',fontSize:15,textAlign:'center',fontFamily:'NunitoSans-Bold'}}>
                    {frist_split_syntax}
                    <Text style={{color:'#414141',fontWeight:'bold'}}>
                        {type==0?second_split_syntax:""}
                    </Text>
                    <Text  style={{alignSelf:'center',color:'#958C63'}}>
                        {third_split_syntax}
                    </Text> 
                    <Text style={{alignSelf:'center',color:'#414141',fontWeight:'bold'}}>
                        {fourth_split_syntax}
                    </Text>
                </Text>
            </View>
        </View>
   )
}
export default TextBox;