import React, { useState, useEffect } from 'react';
import { Text, View,Image, StyleSheet, LayoutAnimation, Platform, UIManager, TouchableOpacity,ScrollView, StatusBar, TextInput } from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import CustomText from '../CustomText';
import { CustomTextInputInfo } from '../customview';
import colors from '../../utility/color';


export function Footer({navigation,icon,text,style}){
  return(
    <TouchableOpacity onPress={() => navigation.navigate('SaveLocationScreen')}>
      <View style={style}>
        <View 
          style={{
            justifyContent:'center',
            flexDirection:'row',
            backgroundColor:colors.
            FONT_COLOR,
            width:wp('20%'),
            height:'auto',
            borderRadius:5,
            paddingTop:10,
            paddingBottom:10
          }}
        >
          <Image 
            source={icon} 
            resizeMode='contain' 
            style={{alignSelf:'center',tintColor:colors.WHITE,width:wp('13.5%'),height:hp('8.5%')}}
          ></Image>
        </View>
        <CustomText style={{textAlign:'center',right:wp('5%'), fontSize:hp('1.9%'),marginTop:hp('1.5%'),color:colors.FONT_COLOR}}>
          {text}
        </CustomText>
      </View>
    </TouchableOpacity>
  );
}
