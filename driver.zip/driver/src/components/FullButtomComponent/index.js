import React from 'react';
import {StyleSheet} from 'react-native';
import { CustomButton } from '../customview';
import colors from '../../utilty/color';


const FullButtonComponent = props => {
  return (
    <CustomButton {...props} buttonStyle={[styles.button, props.buttonStyle]} />
  );
};
  
const styles = StyleSheet.create({
  button: {
    width: '100%',
    alignItems: 'center',
    backgroundColor:colors.FONT_COLOR,
    height:55,
    justifyContent:'center',
    borderRadius:8
  },
});
  
export default FullButtonComponent;