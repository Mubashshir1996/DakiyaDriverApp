import React,{Component} from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    TextInput,
    StatusBar,
    TouchableOpacity,
} from 'react-native';

const CommonTextBox = ({value,colorstate,isBold,size})  => {
    return(
        <View style={{flex:1,flexDirection:'row',justifyContent:'center'}}>
            <View style={{alignContent:'center'}}>
                <Text 
                    style={{
                        color:colorstate,
                        fontSize:size,
                        textAlign:'center',
                        fontWeight:isBold?'bold':'normal'
                    }}
                >
                    {value}
                </Text>
            </View>
        </View>

    )
}
export default CommonTextBox;