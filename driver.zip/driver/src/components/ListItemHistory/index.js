import React from 'react';
import {
    StyleSheet,
    View,
} from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import { CustomText } from '../customview';
import colors from '../../utility/color';

const Orderhistoryitem = ({data,onPress,style}) =>{
  return(
    <View style={styes.container}>
      <View style={styes.HeaderView}>
        <CustomText style={styes.HeaderViewTitle}>Order Number</CustomText>
        <CustomText style={styes.HeaderViewDescription}>14 mins Ago</CustomText>
      </View>
      <View style={styes.ContentView}>
        <CustomText style={styes.ContentViewtxt1}>
          {data.key}
        </CustomText>
        <CustomText style={styes.ContentViewtxt2}>
          Parcel
        </CustomText>
        <CustomText style={styes.ContentViewtxt3}>
          Address
        </CustomText>
        <View style={styes.ContentViewtxt4}>
          <CustomText style={styes.ContentViewtxt4_txt}>
            Pin Code
          </CustomText>
        </View>
      </View>  
    </View> 
  )
}

export default Orderhistoryitem;

const styes = StyleSheet.create({
  container:{
    width:wp('90%'),
    alignSelf:'center',
    flex:1,
    height:'auto',
    borderWidth:1,
    borderColor:colors.FONT_COLOR,
    borderRadius:10,
    marginBottom:hp('5%')
  },
  
  HeaderView:{
    justifyContent:'space-between',
    flexDirection:'row',
    backgroundColor:colors.FONT_COLOR,
    height:wp('12%'),
    borderRadius:5
  },
  
  HeaderViewTitle:{
    alignSelf:'center',
    marginLeft:10,
    fontSize:hp('2.2%'),
    fontFamily:'NunitoSans-Bold',
    color:colors.WHITE
  },
  
  HeaderViewDescription:{
    alignSelf:'center',
    justifyContent:'space-between' 
    ,fontSize:hp('1.7%'),
    color:colors.WHITE,
    fontFamily:'NunitoSans-Light'
  },
  
  ContentView:{
    flexDirection:'column',
    marginTop:wp('2%'),
    marginLeft:wp('3%'),
    marginRight:1.5
  },
  
  ContentViewtxt1:{
    marginTop:10,
    color:'black',
    fontSize:hp('2%'),
    fontFamily:'NunitoSans-SemiBold'
  },
  
  ContentViewtxt2:{
    marginTop:10,
    color:'black',
    fontSize:hp('2%'),
    fontFamily:'NunitoSans-SemiBold'
  },
  
  ContentViewtxt3:{
    marginTop:10,
    color:'black',
    fontSize:hp('2%'),
    fontFamily:'NunitoSans-SemiBold'
  },
  
  ContentViewtxt4:{
    flexDirection:'row',
    justifyContent:'space-between',
    marginTop:hp('1%'),
    marginBottom:hp('1.5%'),
    fontFamily:'NunitoSans-SemiBold'
  },
  
  ContentViewtxt4_txt:{
    color:'black',
    fontSize:hp('2%'),
    alignSelf:'center',
    fontFamily:'NunitoSans-SemiBold'
  }

})

