import React,{Component} from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    TextInput,
    StatusBar,
    Image
} from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';

const InputBox = ({ children, value, onChange, ...props })  => {
    return(
        <View style={{flexDirection:'row',height:55,borderRadius:0  ,borderWidth:1.5,borderColor:'#958C63',marginRight:'7%',marginLeft:'7%'}} >   
            <Image 
                source={require('../assets/ic_mobile.png')} 
                resizeMode='center' 
                style={{alignSelf:'center',padding:0,margin:0,width:30,height:30}}
            ></Image>
            <Text style={{flexDirection:'column',width:30,textAlign:'center',height:30,marginTop:12,fontSize:17,color:'#414141',marginLeft:5}} >+91</Text> 
            <Text style={{height:40,marginLeft:10,backgroundColor:'#958C63',flexDirection:'column',width:1.5,marginTop:5}}></Text>
            <TextInput 
                style={{
                    flexDirection:'column',
                    marginTop:5,
                    marginLeft:10,
                    width:'79%',
                    height:40,
                    backgroundColor:'transparent'
                }} 
                underlineColorAndroid='transparent'
            ></TextInput>
        </View> 
    )

}

 export default InputBox; 