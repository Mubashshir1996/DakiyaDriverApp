
import React,{Component} from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    TextInput,
    StatusBar,
    TouchableOpacity,
} from 'react-native';


const ButtonBox  = ({press,children, value, onChange, ...props })  => {
  
    return(
        <View  style={{flex:1,flexDirection:'row',justifyContent:'center'}}>
            <TouchableOpacity onPress={press}>
                <View style={{justifyContent:'center',backgroundColor:'#958C63',marginLeft:'30%',marginRight:'30%',height:63,borderRadius:6}}>
                    <View  style={{alignSelf:'center',width:600}}>
                        <Text style={{color:'#fff',fontSize:20,textAlign:'center'}}>Submit</Text>
                    </View>
                </View>
            </TouchableOpacity>
        </View>
    ) 

}

export default ButtonBox;