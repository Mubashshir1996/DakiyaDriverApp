import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList,
    KeyboardAvoidingView
} from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../utility/color';
import CustomText from '../CustomText';

const TextBoxImage = ({name,onChangeText,placename,path,type,width,height,leftMar,keyboardType,returnKeyType,levelfontSize,inputFontSize,fontfamily,right,rightInput,placeholderColor}) =>{
  const fontSize = inputFontSize; 
  const types = type;
  return(   
    <View style={{flexDirection:'column',flex:1,right:right}}>
      {types === 0 ? 
        <CustomText style={{marginLeft:wp('8%'),fontSize:levelfontSize,fontfamily:fontfamily,}}>{name}</CustomText>
        : 
        <View>   
        </View>
      }
      <View style={styles.searchSection}>
        <Image 
          source={path} style={{width:width,height,marginLeft:leftMar}} 
          resizeMode='contain'
        ></Image>
        <Text  
          style={{alignSelf:'center',
          marginLeft:wp('8%'),
          fontFamily:fontfamily, 
          flex: 1,
          paddingTop: 10,
          paddingRight: 10,
          paddingBottom: 10,
          paddingLeft: 0,
          color: colors.FONT_COLOR,fontSize:fontSize,right:rightInput}}
          underlineColorAndroid="transparent"
          onChangeText={onChangeText}
        >
          {placename}
        </Text>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  searchSection: {
    marginLeft:wp('5%'),
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop:10
  },

  searchIcon: {
    flex:1
  },
    
  input: {
    alignSelf:'center',
    marginLeft:wp('8%'),
    flex: 1,
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 0,
    color: colors.FONT_COLOR, 
  },
      
})

  export default TextBoxImage;