import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    TouchableOpacity
} from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { CustomText } from '../customview';
import colors from '../../utility/color';

const ListOrderH = ({navigation,data,onPress,style}) =>{
  return(
    <TouchableOpacity onPress={() => navigation.navigate('OrderSlipScreen')}>
      <View style={{width:wp('90%'),alignSelf:'center',flex:1,height:'auto',borderWidth:1,borderColor:colors.FONT_COLOR,borderRadius:10,marginBottom:hp('5%')}}>
        <View style={{justifyContent:'space-between',flexDirection:'row',backgroundColor:colors.FONT_COLOR,height:wp('12%'),borderRadius:5}}>
          <CustomText style={{alignSelf:'center',marginLeft:10,fontSize:hp('2.2%'),color:colors.WHITE,fontFamily:'NunitoSans-Bold'}}>Order Number</CustomText>
          <CustomText style={{alignSelf:'center',justifyContent:'space-between',right:wp('1%'),fontFamily:'NunitoSans-Light',fontSize:hp('1.7%'),color:colors.WHITE}}>14 mins Ago</CustomText>
        </View>
        <View style={{flexDirection:'column',marginTop:wp('2%'),marginLeft:wp('3%'),marginRight:1.5}}>
          <CustomText style={{marginTop:10,color:'black',fontSize:hp('2%'),fontFamily:'NunitoSans-Regular'}}>
            {data}
          </CustomText>
          <CustomText style={{marginTop:10,color:'black',fontSize:hp('2%'),fontFamily:'NunitoSans-Regular'}}>
            Parcel
          </CustomText>
          <CustomText style={{fontFamily:'NunitoSans-Regular',marginTop:10,color:'black',fontSize:hp('2%')}}>
            Address
          </CustomText>    
          <View style={{flexDirection:'row',justifyContent:'space-between'}}>
            <CustomText style={{color:'black',fontFamily:'NunitoSans-Regular',fontSize:hp('2%'),alignSelf:'center'}}>
              Pin Code
            </CustomText>
            <View style={{height:hp('7%'),flex:1,borderColor:colors.GREEN,borderRadius:6,borderWidth:2,alignSelf:'center',justifyContent:'center',marginLeft:wp('40%'),marginRight:hp('2%'),bottom:hp('2.8%')}}>
              <CustomText style={{justifyContent:'center',left:wp('1.5%'),fontFamily:'NunitoSans-Bold',color:colors.BLACK,fontSize:hp('2.1%'),alignSelf:'center'}}>
                Accept
              </CustomText>
            </View>
          </View>
        </View>  
      </View> 
    </TouchableOpacity>
  )
}

export default ListOrderH;

