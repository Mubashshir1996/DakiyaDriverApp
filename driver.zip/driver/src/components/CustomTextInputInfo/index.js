import React from 'react';
import {StyleSheet, View, ViewPropTypes, TextInput} from 'react-native';
import PropTypes from 'prop-types';
import colors from '../../utility/color';
import { GenericStyles } from '../../screens/otp/GenericStyles';


const CustomTextInputInfo = function(props) {
  const {
    placeholder,
    containerStyle,
    style,
    LeftComponent,
    RightComponent,
    refCallback,
    ...remainingProps
  } = props;
  
  return (
    <View style={[styles.containerStyle, containerStyle]}>
      {LeftComponent}
      <TextInput
        {...remainingProps}
        style={[styles.textInputStyle, GenericStyles.fill, style]}
        ref={refCallback}
        placeholder={placeholder}
      />
      {RightComponent}
    </View>
  );
};
  
const styles = StyleSheet.create({
  containerStyle: {
    flexDirection: 'row',
    borderRadius: 4,
    padding: 0,
  },
  textInputStyle: {
    padding: 0,
  },
});
  
CustomTextInputInfo.defaultProps = {
  LeftComponent: <></>,
  RightComponent: <></>,
};
  
CustomTextInputInfo.propTypes = {
  containerStyle: ViewPropTypes.style,
  style: ViewPropTypes.style,
  LeftComponent: PropTypes.object,
  RightComponent: PropTypes.object,
  refCallback: PropTypes.func,
};

export default CustomTextInputInfo;
  

