import React from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    StatusBar,
    TextInput,
    Image,
    FlatList,
    KeyboardAvoidingView,
    TouchableOpacity
} from 'react-native';
import { Icon, Avatar, Card } from 'react-native-elements'
import CustomText from '../CustomText';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import colors from '../../utility/color';


function WalletlistItem({data,navigation}){
  return(
    <View style={{alignSelf:'center',flexDirection:'column',aspectRatio:4.5,marginTop:hp('2%'),height:hp('11%')}}>      
      <View style={{flex:1, justifyContent:'space-between', flexDirection:'row',aspectRatio:4.5}}>
        <View style={{flexDirection:'row'}}>
          <View style={{alignSelf:'center',justifyContent:'center', aspectRatio:1,height:hp('7%'),borderRadius:5,backgroundColor:colors.FONT_COLOR,marginLeft:hp('1%'),marginBottom:wp('2%'),marginTop:hp('2%'),marginRight:wp('1%')}}>
            <CustomText style={{alignSelf:'center',justifyContent:'center',marginLeft:wp('4.8%'),color:colors.WHITE,fontSize:hp('3%'),fontFamily:'NunitoSans-Bold'}}>{data.name.charAt(0)}</CustomText>
          </View>
          <View style={{flexDirection:'column',alignSelf:'center'}}>
            <CustomText style={{marginLeft:5,fontSize:hp('2%'),fontFamily:'NunitoSans-Bold',color:colors.BLACK}}>{data.name}</CustomText>
            <CustomText style={{fontSize:hp('1.8%'),marginLeft:5,marginTop:4,fontFamily:'NunitoSans-Bold',color:colors.LIGHT_GREY}}>{data.time}</CustomText>
          </View>
        </View>
        {data.amount_status == "low"?(
          <CustomText style={{fontSize:hp('1.8%'),alignSelf:'center',fontFamily:'NunitoSans-Bold',color:colors.RED}}>{data.amount}</CustomText>
          )
          :
          (
          <CustomText style={{fontSize:hp('1.8%'),alignSelf:'center',fontFamily:'NunitoSans-Bold',color:colors.GREEN}}>{data.amount}</CustomText>
          )
        }
      </View>
    </View>
  );
}

export default WalletlistItem;


   