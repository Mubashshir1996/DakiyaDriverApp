import React,{Component} from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    TextInput,
    StatusBar,
} from 'react-native';
import { Content, Item, Input } from 'native-base';
import { Grid, Col } from 'react-native-easy-grid';

const otpTextInput = [];
  
function renderInputs() {
    const inputs = Array(6).fill(0);
    const txt = inputs.map(
        (i, j) => 
            <Col key={j} style={styles.txtMargin}>
                <Item regular>
                    <Input
                        style={[styles.inputRadius, { borderRadius: 10 }]}
                        keyboardType="numeric"
                        onChangeText={v => focusNext(j, v)}
                        onKeyPress={e => focusPrevious(e.nativeEvent.key, j)}
                        ref={ref => otpTextInput[j] = ref}
                    />
                </Item>
            </Col>
    );
    return txt;
}

function focusPrevious(key, index) {
    if (key === 'Backspace' && index !== 0)
        otpTextInput[index - 1]._root.focus();
}


const OtpBox = ({otpTextInput, children, value, onChange, ...props })  => {
    return(
        <View style={{flex:1,flexDirection:'row'}}>
            <Content padder>
                <Grid style={styles.gridPad}>
                    {renderInputs()}
                </Grid>
            </Content>
        </View>
    );
}


function focusNext(index, value) {
    if (index < otpTextInput.length - 1 && value) {
        otpTextInput[index + 1]._root.focus();
    }
    if (index === otpTextInput.length - 1) {
        otpTextInput[index]._root.blur();
    }
    const otp = this.state.otp;
    otp[index] = value;
    this.setState({ otp });
    this.props.getOtp(otp.join(''));
}


const styles = StyleSheet.create({
    gridPad: { padding: 30 },
    txtMargin: { margin: 3 },
    inputRadius: { textAlign: 'center' }
});

export default OtpBox;